# vte-gtk2

Utrzymywana, zachowawcza wersja widgetu terminala VTE dla aplikacji GTK2.
Projekt ma dostarczać stare API VTE na systemach z glibc i musl, przede
wszystkim dla desktopu GTK2 instalowanego pod `/opt/gtk2`. Nie jest to port
do GTK3 ani próba rozwijania nowego emulatora terminala.

## Stan

Utrzymywana baza opiera się na oficjalnym wydaniu GNOME VTE 0.28.2. W drzewie są:

- kompletne źródła wydania 0.28.2;
- ograniczenia parsera z poprawki CVE-2012-2738 oraz limity wejścia
  CSI/OSC/DCS;
- małe poprawki kompilacji dla musl oraz współczesnych kompilatorów;
- poprawki UTF-8, klawiatury, kolorów, italic, raportowania fokusu i myszy
  xterm;
- poprawki ringu i prywatnego strumienia scrollbacku, zachowujące cały
  widoczny ekran w pamięci;
- aktualne `config.guess` i `config.sub` dla nowych tripletów;
- prosty przykład GTK2 w `examples/`;
- szkic zasad pakowania dla Alpine w `packaging/alpine/`.

Publiczne nagłówki, eksportowane symbole, nazwa modułu pkg-config `vte`, API
`0.0` i SONAME `libvte.so.9` pozostają bez zmian. Szczegóły pochodzenia,
zależności i klasyfikację zmian zawiera `NOTES.md`. Zmiany przeznaczone do
publikacji są prowadzone w `CHANGELOG.md`.

Aktualny zestaw zmian jest opisany jako `0.28.2-gtk2.4`. Jest to numer wydania
forka, a nie zmiana wersji deklarowanej przez historyczne API: makra wersji,
moduł pkg-config i libtool pozostają na 0.28.2, aby stare aplikacje nie dostały
sztucznej niezgodności. Dokładny kod wydania należy oznaczyć tagiem forka.

## Budowanie

Do zbudowania wariantu GTK2 potrzebne są co najmniej: kompilator C, make,
pkg-config, libtool, intltool/gettext, GTK+ 2.20, GLib 2.26, Pango 1.22 oraz
implementacja termcap (`ncurses`/`tinfo`). Dla backendu X11 potrzebne są też
Xlib i cairo-xlib; zwykle przychodzą z pakietami deweloperskimi GTK2.

Z wydania zawierającego wygenerowany skrypt `configure`:

```sh
./configure \
  --prefix=/opt/gtk2 \
  --with-gtk=2.0 \
  --disable-python \
  --disable-introspection \
  --disable-gtk-doc \
  --disable-gnome-pty-helper
make -j2
make check
```

Obsługa kolorów 24-bitowych jest świadomie opcjonalna. Aby włączyć sekwencje
`SGR 38;2;R;G;B` i `48;2;R;G;B`, dodaj do konfiguracji:

```sh
./configure --enable-truecolor [pozostałe opcje]
```

Tryb domyślny zachowuje 8-bajtową prywatną komórkę VTE 0.28.2. Truecolor
zwiększa ją do 12 bajtów, ale nie zmienia publicznych nagłówków, SONAME ani
listy eksportowanych symboli. Dla `/opt/gtk2` decyzję należy podjąć jednolicie
dla wszystkich architektur pakietu.

Nie uruchamiaj `make install` na systemie roboczym. Instalację pakietową można
sprawdzić w kontenerze przez `make DESTDIR="$pkgdir" install`.

Python 2/PyGTK jest opcjonalną częścią oryginalnego wydania i domyślnie było
włączone. Źródła bindingów pozostają w drzewie, ale dla nowego pakietu należy
jawnie użyć `--disable-python`: stos Pythona 2 jest niewspierany i nie jest
potrzebny do ABI biblioteki C.

`gnome-pty-helper` również pozostaje w drzewie. Kompiluje się na obu badanych
libc, lecz dla pierwszego pakietu `/opt/gtk2` zalecane jest jego wyłączenie.
Włączenie wymaga osobnego przeglądu instalacji setuid, uprawnień oraz zachowania
utmp/wtmp/lastlog.

## Szybki test ręczny

Po zainstalowaniu biblioteki i pliku `vte.pc`:

```sh
make -C examples
./examples/vte-gtk2-smoke
```

Program otwiera okno GTK2 z terminalem i uruchamia `/bin/sh`. Główne
`make check` wykonuje pięć testów wewnętrznych bez okna. Dziewięć testów
integracyjnych publicznego API wymaga X11 i można je wykonać bezgłowo:

```sh
make -C examples
xvfb-run -a make -C examples check
```

Testy integracyjne obejmują UTF-8 i CJK, kolory, fragmenty komórek,
zaznaczanie, dopasowania regex, bracketed paste, cykl życia PTY oraz sekwencje
ruchu kursora i przewijania. Korzystają z instalowanej
biblioteki i wymagają odpowiadającego jej pliku
`share/vte/termcap-0.0/xterm`.

## Archiwum wydaniowe

Publikowalny tarball XZ należy tworzyć w pełnym środowisku wydaniowym w
kontenerze. W odróżnieniu od zwykłego profilu pakietowego potrzebne jest
gtk-doc, a podprojekt `gnome-pty-helper` musi zostać skonfigurowany, aby jego
źródła mogły wejść do archiwum (nie oznacza to, że helper ma trafić do APK):

```sh
./configure \
  --prefix=/opt/gtk2 \
  --with-gtk=2.0 \
  --disable-python \
  --disable-introspection \
  --enable-gtk-doc
make -j2
make dist-xz
```

Przed publikacją kolejnego wydania należy przenieść jego wpisy z sekcji
`Unreleased` do nazwanej sekcji, utworzyć tag i obliczyć sumę archiwum z
dokładnie tego commita. Tarball jest artefaktem wydania i nie powinien być
commitowany do repozytorium.

## Ograniczenia i dalsze prace

- kompilacja, testy wewnętrzne i testy integracyjne pod Xvfb przechodzą na
  sprawdzonych środowiskach glibc i musl/x86_64; nie oznacza to pełnej
  zgodności zachowania wszystkich sekwencji terminalowych;
- ostrzeżenia o przestarzałych API GTK2/GLib są spodziewane i nie oznaczają
  zmiany ABI;
- baza już obsługuje bracketed paste, a fork dodał raportowanie myszy SGR
  1006 i fokusu 1004 oraz poprawił Alt/Meta, Home/End i kodowanie
  modyfikatorów; truecolor jest dostępny jako opcja builda ze względu na
  większy prywatny rekord komórki;
- aarch64 wymaga wykonania tej samej macierzy na natywnym runnerze albo pod
  kontrolowanym QEMU; w bieżącym środowisku nie ma takiego toolchainu;
- zbudowanie i instalacja APK należą do osobnego repozytorium aports i nie są
  częścią sprawdzeń wykonywanych w tym repozytorium.

Licencja kodu bazowego: GNU Library General Public License v2 lub późniejsza
(`LGPL-2.0-or-later`); pełny tekst znajduje się w `COPYING`.
