/* ANSI-C code produced by gperf version 3.0.3 */
/* Command-line: gperf -m 100 vteseq-n.gperf  */
/* Computed positions: -k'1,8,12' */

#if !((' ' == 32) && ('!' == 33) && ('"' == 34) && ('#' == 35) \
      && ('%' == 37) && ('&' == 38) && ('\'' == 39) && ('(' == 40) \
      && (')' == 41) && ('*' == 42) && ('+' == 43) && (',' == 44) \
      && ('-' == 45) && ('.' == 46) && ('/' == 47) && ('0' == 48) \
      && ('1' == 49) && ('2' == 50) && ('3' == 51) && ('4' == 52) \
      && ('5' == 53) && ('6' == 54) && ('7' == 55) && ('8' == 56) \
      && ('9' == 57) && (':' == 58) && (';' == 59) && ('<' == 60) \
      && ('=' == 61) && ('>' == 62) && ('?' == 63) && ('A' == 65) \
      && ('B' == 66) && ('C' == 67) && ('D' == 68) && ('E' == 69) \
      && ('F' == 70) && ('G' == 71) && ('H' == 72) && ('I' == 73) \
      && ('J' == 74) && ('K' == 75) && ('L' == 76) && ('M' == 77) \
      && ('N' == 78) && ('O' == 79) && ('P' == 80) && ('Q' == 81) \
      && ('R' == 82) && ('S' == 83) && ('T' == 84) && ('U' == 85) \
      && ('V' == 86) && ('W' == 87) && ('X' == 88) && ('Y' == 89) \
      && ('Z' == 90) && ('[' == 91) && ('\\' == 92) && (']' == 93) \
      && ('^' == 94) && ('_' == 95) && ('a' == 97) && ('b' == 98) \
      && ('c' == 99) && ('d' == 100) && ('e' == 101) && ('f' == 102) \
      && ('g' == 103) && ('h' == 104) && ('i' == 105) && ('j' == 106) \
      && ('k' == 107) && ('l' == 108) && ('m' == 109) && ('n' == 110) \
      && ('o' == 111) && ('p' == 112) && ('q' == 113) && ('r' == 114) \
      && ('s' == 115) && ('t' == 116) && ('u' == 117) && ('v' == 118) \
      && ('w' == 119) && ('x' == 120) && ('y' == 121) && ('z' == 122) \
      && ('{' == 123) && ('|' == 124) && ('}' == 125) && ('~' == 126))
/* The character set is not based on ISO-646.  */
#error "gperf generated tables don't work with this execution character set. Please report a bug to <bug-gnu-gperf@gnu.org>."
#endif

#line 16 "vteseq-n.gperf"
struct vteseq_n_struct {
	int seq;
	VteTerminalSequenceHandler handler;
};
#include <string.h>
/* maximum key range = 86, duplicates = 0 */

#ifdef __GNUC__
__inline
#else
#ifdef __cplusplus
inline
#endif
#endif
static unsigned int
vteseq_n_hash (register const char *str, register unsigned int len)
{
  static const unsigned char asso_values[] =
    {
      92, 92, 92, 92, 92, 92, 92, 92, 92, 92,
      92, 92, 92, 92, 92, 92, 92, 92, 92, 92,
      92, 92, 92, 92, 92, 92, 92, 92, 92, 92,
      92, 92, 92, 92, 92, 92, 92, 92, 92, 92,
      92, 92, 92, 92, 92, 20, 92, 92, 92, 92,
      92, 92, 92, 92, 92, 92, 92, 92, 92, 92,
      92, 92, 92, 92, 92, 92, 92, 92, 92, 92,
      92, 92, 92, 92, 92, 92, 92, 92, 92, 92,
      92, 92, 92, 92, 92, 92, 92, 92, 92, 92,
      92, 92, 92, 92, 92, 92, 92,  5,  3,  3,
       0,  7, 50, 92, 29,  2, 92, 37,  8, 16,
       4,  7,  1, 92, 28,  0,  5, 38, 29, 13,
      92, 19, 92, 92, 92, 92, 92, 92, 92, 92,
      92, 92, 92, 92, 92, 92, 92, 92, 92, 92,
      92, 92, 92, 92, 92, 92, 92, 92, 92, 92,
      92, 92, 92, 92, 92, 92, 92, 92, 92, 92,
      92, 92, 92, 92, 92, 92, 92, 92, 92, 92,
      92, 92, 92, 92, 92, 92, 92, 92, 92, 92,
      92, 92, 92, 92, 92, 92, 92, 92, 92, 92,
      92, 92, 92, 92, 92, 92, 92, 92, 92, 92,
      92, 92, 92, 92, 92, 92, 92, 92, 92, 92,
      92, 92, 92, 92, 92, 92, 92, 92, 92, 92,
      92, 92, 92, 92, 92, 92, 92, 92, 92, 92,
      92, 92, 92, 92, 92, 92, 92, 92, 92, 92,
      92, 92, 92, 92, 92, 92, 92, 92, 92, 92,
      92, 92, 92, 92, 92, 92
    };
  register int hval = len;

  switch (hval)
    {
      default:
        hval += asso_values[(unsigned char)str[11]];
      /*FALLTHROUGH*/
      case 11:
      case 10:
      case 9:
      case 8:
        hval += asso_values[(unsigned char)str[7]];
      /*FALLTHROUGH*/
      case 7:
      case 6:
      case 5:
      case 4:
      case 3:
      case 2:
      case 1:
        hval += asso_values[(unsigned char)str[0]];
        break;
    }
  return hval;
}

struct vteseq_n_pool_t
  {
    char vteseq_n_pool_str6[sizeof("decset")];
    char vteseq_n_pool_str7[sizeof("index")];
    char vteseq_n_pool_str9[sizeof("save-mode")];
    char vteseq_n_pool_str10[sizeof("soft-reset")];
    char vteseq_n_pool_str11[sizeof("scroll-down")];
    char vteseq_n_pool_str12[sizeof("tab-set")];
    char vteseq_n_pool_str13[sizeof("decreset")];
    char vteseq_n_pool_str14[sizeof("cursor-down")];
    char vteseq_n_pool_str15[sizeof("set-mode")];
    char vteseq_n_pool_str16[sizeof("set-cursor-style")];
    char vteseq_n_pool_str17[sizeof("next-line")];
    char vteseq_n_pool_str19[sizeof("tab-clear")];
    char vteseq_n_pool_str20[sizeof("delete-lines")];
    char vteseq_n_pool_str21[sizeof("set-window-title")];
    char vteseq_n_pool_str22[sizeof("insert-lines")];
    char vteseq_n_pool_str23[sizeof("set-icon-title")];
    char vteseq_n_pool_str24[sizeof("cursor-position")];
    char vteseq_n_pool_str25[sizeof("delete-characters")];
    char vteseq_n_pool_str26[sizeof("dec-device-status-report")];
    char vteseq_n_pool_str27[sizeof("erase-in-display")];
    char vteseq_n_pool_str28[sizeof("erase-in-line")];
    char vteseq_n_pool_str29[sizeof("set-icon-and-window-title")];
    char vteseq_n_pool_str30[sizeof("screen-alignment-test")];
    char vteseq_n_pool_str31[sizeof("set-scrolling-region")];
    char vteseq_n_pool_str32[sizeof("cursor-preceding-line")];
    char vteseq_n_pool_str33[sizeof("change-cursor-colors")];
    char vteseq_n_pool_str34[sizeof("cursor-backward")];
    char vteseq_n_pool_str35[sizeof("character-attributes")];
    char vteseq_n_pool_str36[sizeof("cursor-character-absolute")];
    char vteseq_n_pool_str37[sizeof("line-position-absolute")];
    char vteseq_n_pool_str38[sizeof("set-scrolling-region-to-end")];
    char vteseq_n_pool_str39[sizeof("save-cursor")];
    char vteseq_n_pool_str40[sizeof("send-secondary-device-attributes")];
    char vteseq_n_pool_str41[sizeof("cursor-back-tab")];
    char vteseq_n_pool_str42[sizeof("set-scrolling-region-from-start")];
    char vteseq_n_pool_str43[sizeof("cursor-next-line")];
    char vteseq_n_pool_str44[sizeof("character-position-absolute")];
    char vteseq_n_pool_str45[sizeof("reset-mode")];
    char vteseq_n_pool_str46[sizeof("change-color")];
    char vteseq_n_pool_str47[sizeof("scroll-up")];
    char vteseq_n_pool_str48[sizeof("application-keypad")];
    char vteseq_n_pool_str49[sizeof("window-manipulation")];
    char vteseq_n_pool_str50[sizeof("cursor-up")];
    char vteseq_n_pool_str51[sizeof("send-primary-device-attributes")];
    char vteseq_n_pool_str52[sizeof("vertical-tab")];
    char vteseq_n_pool_str53[sizeof("return-terminal-id")];
    char vteseq_n_pool_str54[sizeof("linux-console-cursor-attributes")];
    char vteseq_n_pool_str55[sizeof("erase-characters")];
    char vteseq_n_pool_str56[sizeof("cursor-lower-left")];
    char vteseq_n_pool_str57[sizeof("return-terminal-status")];
    char vteseq_n_pool_str58[sizeof("device-status-report")];
    char vteseq_n_pool_str59[sizeof("normal-keypad")];
    char vteseq_n_pool_str60[sizeof("full-reset")];
    char vteseq_n_pool_str62[sizeof("restore-cursor")];
    char vteseq_n_pool_str65[sizeof("insert-blank-characters")];
    char vteseq_n_pool_str66[sizeof("form-feed")];
    char vteseq_n_pool_str67[sizeof("restore-mode")];
    char vteseq_n_pool_str68[sizeof("reverse-index")];
    char vteseq_n_pool_str71[sizeof("horizontal-and-vertical-position")];
    char vteseq_n_pool_str72[sizeof("cursor-forward")];
    char vteseq_n_pool_str74[sizeof("iso8859-1-character-set")];
    char vteseq_n_pool_str83[sizeof("cursor-forward-tabulation")];
    char vteseq_n_pool_str89[sizeof("utf-8-character-set")];
    char vteseq_n_pool_str91[sizeof("request-terminal-parameters")];
  };
static const struct vteseq_n_pool_t vteseq_n_pool_contents =
  {
    "decset",
    "index",
    "save-mode",
    "soft-reset",
    "scroll-down",
    "tab-set",
    "decreset",
    "cursor-down",
    "set-mode",
    "set-cursor-style",
    "next-line",
    "tab-clear",
    "delete-lines",
    "set-window-title",
    "insert-lines",
    "set-icon-title",
    "cursor-position",
    "delete-characters",
    "dec-device-status-report",
    "erase-in-display",
    "erase-in-line",
    "set-icon-and-window-title",
    "screen-alignment-test",
    "set-scrolling-region",
    "cursor-preceding-line",
    "change-cursor-colors",
    "cursor-backward",
    "character-attributes",
    "cursor-character-absolute",
    "line-position-absolute",
    "set-scrolling-region-to-end",
    "save-cursor",
    "send-secondary-device-attributes",
    "cursor-back-tab",
    "set-scrolling-region-from-start",
    "cursor-next-line",
    "character-position-absolute",
    "reset-mode",
    "change-color",
    "scroll-up",
    "application-keypad",
    "window-manipulation",
    "cursor-up",
    "send-primary-device-attributes",
    "vertical-tab",
    "return-terminal-id",
    "linux-console-cursor-attributes",
    "erase-characters",
    "cursor-lower-left",
    "return-terminal-status",
    "device-status-report",
    "normal-keypad",
    "full-reset",
    "restore-cursor",
    "insert-blank-characters",
    "form-feed",
    "restore-mode",
    "reverse-index",
    "horizontal-and-vertical-position",
    "cursor-forward",
    "iso8859-1-character-set",
    "cursor-forward-tabulation",
    "utf-8-character-set",
    "request-terminal-parameters"
  };
#define vteseq_n_pool ((const char *) &vteseq_n_pool_contents)
#ifdef __GNUC__
__inline
#ifdef __GNUC_STDC_INLINE__
__attribute__ ((__gnu_inline__))
#endif
#endif
const struct vteseq_n_struct *
vteseq_n_lookup (register const char *str, register unsigned int len)
{
  enum
    {
      TOTAL_KEYWORDS = 64,
      MIN_WORD_LENGTH = 5,
      MAX_WORD_LENGTH = 32,
      MIN_HASH_VALUE = 6,
      MAX_HASH_VALUE = 91
    };

  static const unsigned char lengthtable[] =
    {
       0,  0,  0,  0,  0,  0,  6,  5,  0,  9, 10, 11,  7,  8,
      11,  8, 16,  9,  0,  9, 12, 16, 12, 14, 15, 17, 24, 16,
      13, 25, 21, 20, 21, 20, 15, 20, 25, 22, 27, 11, 32, 15,
      31, 16, 27, 10, 12,  9, 18, 19,  9, 30, 12, 18, 31, 16,
      17, 22, 20, 13, 10,  0, 14,  0,  0, 23,  9, 12, 13,  0,
       0, 32, 14,  0, 23,  0,  0,  0,  0,  0,  0,  0,  0, 25,
       0,  0,  0,  0,  0, 19,  0, 27
    };
  static const struct vteseq_n_struct wordlist[] =
    {
      {-1}, {-1}, {-1}, {-1}, {-1}, {-1},
#line 25 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str6, VTE_SEQUENCE_HANDLER(vte_sequence_handler_decset)},
#line 24 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str7, VTE_SEQUENCE_HANDLER(vte_sequence_handler_index)},
      {-1},
#line 33 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str9, VTE_SEQUENCE_HANDLER(vte_sequence_handler_save_mode)},
#line 39 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str10, VTE_SEQUENCE_HANDLER(vte_sequence_handler_soft_reset)},
#line 43 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str11, VTE_SEQUENCE_HANDLER(vte_sequence_handler_scroll_down)},
#line 27 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str12, VTE_SEQUENCE_HANDLER(vte_sequence_handler_st)},
#line 28 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str13, VTE_SEQUENCE_HANDLER(vte_sequence_handler_decreset)},
#line 40 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str14, VTE_SEQUENCE_HANDLER(vte_sequence_handler_DO)},
#line 29 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str15, VTE_SEQUENCE_HANDLER(vte_sequence_handler_set_mode)},
#line 72 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str16, VTE_SEQUENCE_HANDLER(vte_sequence_handler_set_cursor_style)},
#line 32 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str17, VTE_SEQUENCE_HANDLER(vte_sequence_handler_next_line)},
      {-1},
#line 35 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str19, VTE_SEQUENCE_HANDLER(vte_sequence_handler_tab_clear)},
#line 45 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str20, VTE_SEQUENCE_HANDLER(vte_sequence_handler_delete_lines)},
#line 71 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str21, VTE_SEQUENCE_HANDLER(vte_sequence_handler_set_window_title)},
#line 47 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str22, VTE_SEQUENCE_HANDLER(vte_sequence_handler_insert_lines)},
#line 61 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str23, VTE_SEQUENCE_HANDLER(vte_sequence_handler_set_icon_title)},
#line 64 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str24, VTE_SEQUENCE_HANDLER(vte_sequence_handler_cursor_position)},
#line 74 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str25, VTE_SEQUENCE_HANDLER(vte_sequence_handler_DC)},
#line 110 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str26, VTE_SEQUENCE_HANDLER(vte_sequence_handler_dec_device_status_report)},
#line 70 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str27, VTE_SEQUENCE_HANDLER(vte_sequence_handler_erase_in_display)},
#line 51 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str28, VTE_SEQUENCE_HANDLER(vte_sequence_handler_erase_in_line)},
#line 116 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str29, VTE_SEQUENCE_HANDLER(vte_sequence_handler_set_icon_and_window_title)},
#line 91 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str30, VTE_SEQUENCE_HANDLER(vte_sequence_handler_screen_alignment_test)},
#line 84 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str31, VTE_SEQUENCE_HANDLER(vte_sequence_handler_set_scrolling_region)},
#line 89 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str32, VTE_SEQUENCE_HANDLER(vte_sequence_handler_cursor_preceding_line)},
#line 81 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str33, VTE_SEQUENCE_HANDLER(vte_sequence_handler_change_cursor_color)},
#line 63 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str34, VTE_SEQUENCE_HANDLER(vte_sequence_handler_LE)},
#line 82 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str35, VTE_SEQUENCE_HANDLER(vte_sequence_handler_character_attributes)},
#line 113 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str36, VTE_SEQUENCE_HANDLER(vte_sequence_handler_cursor_character_absolute)},
#line 96 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str37, VTE_SEQUENCE_HANDLER(vte_sequence_handler_line_position_absolute)},
#line 86 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str38, VTE_SEQUENCE_HANDLER(vte_sequence_handler_set_scrolling_region_to_end)},
#line 42 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str39, VTE_SEQUENCE_HANDLER(vte_sequence_handler_sc)},
#line 130 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str40, VTE_SEQUENCE_HANDLER(vte_sequence_handler_send_secondary_device_attributes)},
#line 62 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str41, VTE_SEQUENCE_HANDLER(vte_sequence_handler_bt)},
#line 85 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str42, VTE_SEQUENCE_HANDLER(vte_sequence_handler_set_scrolling_region_from_start)},
#line 68 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str43, VTE_SEQUENCE_HANDLER(vte_sequence_handler_cursor_next_line)},
#line 118 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str44, VTE_SEQUENCE_HANDLER(vte_sequence_handler_character_position_absolute)},
#line 38 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str45, VTE_SEQUENCE_HANDLER(vte_sequence_handler_reset_mode)},
#line 44 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str46, VTE_SEQUENCE_HANDLER(vte_sequence_handler_change_color)},
#line 34 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str47, VTE_SEQUENCE_HANDLER(vte_sequence_handler_scroll_up)},
#line 75 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str48, VTE_SEQUENCE_HANDLER(vte_sequence_handler_application_keypad)},
#line 80 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str49, VTE_SEQUENCE_HANDLER(vte_sequence_handler_window_manipulation)},
#line 30 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str50, VTE_SEQUENCE_HANDLER(vte_sequence_handler_UP)},
#line 127 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str51, VTE_SEQUENCE_HANDLER(vte_sequence_handler_send_primary_device_attributes)},
#line 50 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str52, VTE_SEQUENCE_HANDLER(vte_sequence_handler_vertical_tab)},
#line 77 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str53, VTE_SEQUENCE_HANDLER(vte_sequence_handler_return_terminal_id)},
#line 128 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str54, VTE_SEQUENCE_HANDLER(vte_sequence_handler_noop)},
#line 69 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str55, VTE_SEQUENCE_HANDLER(vte_sequence_handler_erase_characters)},
#line 73 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str56, VTE_SEQUENCE_HANDLER(vte_sequence_handler_cursor_lower_left)},
#line 97 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str57, VTE_SEQUENCE_HANDLER(vte_sequence_handler_return_terminal_status)},
#line 83 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str58, VTE_SEQUENCE_HANDLER(vte_sequence_handler_device_status_report)},
#line 53 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str59, VTE_SEQUENCE_HANDLER(vte_sequence_handler_normal_keypad)},
#line 36 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str60, VTE_SEQUENCE_HANDLER(vte_sequence_handler_full_reset)},
      {-1},
#line 60 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str62, VTE_SEQUENCE_HANDLER(vte_sequence_handler_rc)},
      {-1}, {-1},
#line 100 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str65, VTE_SEQUENCE_HANDLER(vte_sequence_handler_insert_blank_characters)},
#line 31 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str66, VTE_SEQUENCE_HANDLER(vte_sequence_handler_form_feed)},
#line 48 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str67, VTE_SEQUENCE_HANDLER(vte_sequence_handler_restore_mode)},
#line 54 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str68, VTE_SEQUENCE_HANDLER(vte_sequence_handler_reverse_index)},
      {-1}, {-1},
#line 129 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str71, VTE_SEQUENCE_HANDLER(vte_sequence_handler_horizontal_and_vertical_position)},
#line 58 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str72, VTE_SEQUENCE_HANDLER(vte_sequence_handler_RI)},
      {-1},
#line 103 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str74, VTE_SEQUENCE_HANDLER(vte_sequence_handler_local_charset)},
      {-1}, {-1}, {-1}, {-1}, {-1}, {-1}, {-1}, {-1},
#line 114 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str83, VTE_SEQUENCE_HANDLER(vte_sequence_handler_ta)},
      {-1}, {-1}, {-1}, {-1}, {-1},
#line 79 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str89, VTE_SEQUENCE_HANDLER(vte_sequence_handler_utf_8_charset)},
      {-1},
#line 119 "vteseq-n.gperf"
      {(int)(long)&((struct vteseq_n_pool_t *)0)->vteseq_n_pool_str91, VTE_SEQUENCE_HANDLER(vte_sequence_handler_request_terminal_parameters)}
    };

  if (len <= MAX_WORD_LENGTH && len >= MIN_WORD_LENGTH)
    {
      register int key = vteseq_n_hash (str, len);

      if (key <= MAX_HASH_VALUE && key >= 0)
        if (len == lengthtable[key])
          {
            register const char *s = wordlist[key].seq + vteseq_n_pool;

            if (*str == *s && !memcmp (str + 1, s + 1, len - 1))
              return &wordlist[key];
          }
    }
  return 0;
}
