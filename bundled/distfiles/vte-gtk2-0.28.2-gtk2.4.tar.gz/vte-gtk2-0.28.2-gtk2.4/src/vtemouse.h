/*
 * Copyright (C) 2026 vte-gtk2 contributors
 *
 * This is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Library General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#ifndef VTE_VTEMOUSE_H
#define VTE_VTEMOUSE_H

#include <glib.h>

#include "caps.h"

/* Encode one mouse report independently of GTK event handling.  This keeps
 * both the binary legacy fallback and SGR 1006 behavior headlessly testable. */
static gint
_vte_mouse_event_encode(char *buf,
			gsize size,
			int button,
			gboolean is_drag,
			gboolean is_release,
			gboolean shift,
			gboolean meta,
			gboolean control,
			long col,
			long row,
			long column_count,
			long row_count,
			gboolean sgr_1006)
{
	guint cb = 0;
	long cx, cy;

	switch (button) {
	case 0:                 /* Motion with no button pressed. */
		cb = 3;
		break;
	case 1:                 /* Left. */
		cb = 0;
		break;
	case 2:                 /* Middle. */
		cb = 1;
		break;
	case 3:                 /* Right. */
		cb = 2;
		break;
	case 4:                 /* Scroll up. */
		cb = 64;
		break;
	case 5:                 /* Scroll down. */
		cb = 65;
		break;
	default:
		return 0;
	}

	/* Legacy reports identify all releases as button 3.  SGR 1006 retains
	 * the released button and distinguishes release with a lowercase m. */
	if (is_release && !sgr_1006)
		cb = 3;
	if (shift)
		cb |= 4;
	if (meta)
		cb |= 8;
	if (control)
		cb |= 16;
	if (is_drag)
		cb |= 32;

	cx = CLAMP(1 + col, 1, column_count);
	cy = CLAMP(1 + row, 1, row_count);

	if (sgr_1006)
		return g_snprintf(buf, size, _VTE_CAP_CSI "<%u;%ld;%ld%c",
				  cb, cx, cy, is_release ? 'm' : 'M');

	/* Keep the historical upper bound used by VTE.  Wider coordinates
	 * require an extended protocol and are intentionally not truncated. */
	if (cx > 231 || cy > 231)
		return 0;

	return g_snprintf(buf, size, _VTE_CAP_CSI "M%c%c%c",
			  32 + cb, 32 + (guchar)cx, 32 + (guchar)cy);
}

#endif /* VTE_VTEMOUSE_H */
