/*
 * Copyright (C) 2026 vte-gtk2 contributors
 *
 * This is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Library General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#ifndef VTE_VTECOLORS_H
#define VTE_VTECOLORS_H

/* Keep SGR color adjustment independent of drawing and GTK so its xterm
 * compatibility rules can be covered by the existing headless test. */
static void
_vte_adjust_color_indices(guint fore,
			  guint back,
			  gboolean bold,
			  gboolean half,
			  gboolean standout,
			  gboolean fg_sgr_extended,
			  gboolean bg_sgr_extended,
			  guint *adjusted_fore,
			  guint *adjusted_back)
{
	static const guchar corresponding_dim_index[] = {16, 88, 28, 100,
							 18, 90, 30, 102};

	if (bold) {
		if (fore == VTE_DEF_FG)
			fore = VTE_BOLD_FG;
		else if (!fg_sgr_extended && fore < VTE_LEGACY_COLOR_SET_SIZE)
			fore += VTE_COLOR_BRIGHT_OFFSET;
	}

	if (half) {
		if (fore == VTE_DEF_FG)
			fore = VTE_DIM_FG;
		else if (!fg_sgr_extended && fore < VTE_LEGACY_COLOR_SET_SIZE)
			fore = corresponding_dim_index[fore];
	}

	if (standout && !bg_sgr_extended &&
	    back < VTE_LEGACY_COLOR_SET_SIZE)
		back += VTE_COLOR_BRIGHT_OFFSET;

	*adjusted_fore = fore;
	*adjusted_back = back;
}

#endif /* VTE_VTECOLORS_H */
