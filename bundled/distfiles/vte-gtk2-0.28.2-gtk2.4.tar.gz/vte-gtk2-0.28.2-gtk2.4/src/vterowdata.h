/*
 * Copyright (C) 2002 Red Hat, Inc.
 *
 * This is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Library General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/* The interfaces in this file are subject to change at any time. */

#ifndef vterowdata_h_included
#define vterowdata_h_included

#include "vteunistr.h"

G_BEGIN_DECLS

#define VTE_TAB_WIDTH_BITS		4
#define VTE_TAB_WIDTH_MAX		((1 << VTE_TAB_WIDTH_BITS) - 1)


#define VTE_DEF_FG			256
#define VTE_DEF_BG			257
#define VTE_BOLD_FG			258
#define VTE_DIM_FG			259
#define VTE_DEF_HL                      260
#define VTE_CUR_BG			261
#define VTE_PALETTE_SIZE		262

#ifdef VTE_ENABLE_TRUECOLOR
#if __GNUC__ > 2 || (__GNUC__ == 2 && __GNUC_MINOR__ > 6)
#define VTE_GNUC_PACKED __attribute__((__packed__))
#else
#define VTE_GNUC_PACKED
#endif
#define VTE_CELL_ATTR_UINT guint64
#define VTE_CELL_COLOR_BITS 25
#else
#define VTE_GNUC_PACKED
#define VTE_CELL_ATTR_UINT guint32
#define VTE_CELL_COLOR_BITS 9
#endif


/*
 * VteCellAttr: A single cell style attributes
 *
 * Ordered by most commonly changed attributes, to
 * optimize the compact representation.
 */

typedef struct _VteCellAttr {
	VTE_CELL_ATTR_UINT fragment: 1;	/* A continuation cell. */
	VTE_CELL_ATTR_UINT columns: VTE_TAB_WIDTH_BITS;	/* Number of visible columns
				   (as determined by g_unicode_iswide(c)).
				   Also abused for tabs; bug 353610
				   Keep at least 4 for tabs to work
				   */
	VTE_CELL_ATTR_UINT bold: 1;
	VTE_CELL_ATTR_UINT italic: 1;
	VTE_CELL_ATTR_UINT fore: VTE_CELL_COLOR_BITS; /* Palette index or direct RGB. */
	VTE_CELL_ATTR_UINT back: VTE_CELL_COLOR_BITS; /* Palette index or direct RGB. */

	VTE_CELL_ATTR_UINT standout: 1;
	VTE_CELL_ATTR_UINT underline: 1;
	VTE_CELL_ATTR_UINT strikethrough: 1;

	VTE_CELL_ATTR_UINT reverse: 1;
	VTE_CELL_ATTR_UINT blink: 1;
	VTE_CELL_ATTR_UINT half: 1;

	VTE_CELL_ATTR_UINT invisible: 1;
	/* unused; bug 499893
	guint32 protect: 1;
	 */

	/* 31 bits */
} VteCellAttr;
#ifdef VTE_ENABLE_TRUECOLOR
G_STATIC_ASSERT (sizeof (VteCellAttr) == 8);
#else
G_STATIC_ASSERT (sizeof (VteCellAttr) == 4);
#endif

typedef union _VteIntCellAttr {
	VteCellAttr s;
	VTE_CELL_ATTR_UINT i;
} VteIntCellAttr;
G_STATIC_ASSERT (sizeof (VteCellAttr) == sizeof (VteIntCellAttr));

/*
 * VteCell: A single cell's data
 */

typedef struct VTE_GNUC_PACKED _VteCell {
	vteunistr c;
	VteCellAttr attr;
} VteCell;
#ifdef VTE_ENABLE_TRUECOLOR
G_STATIC_ASSERT (sizeof (VteCell) == 12);
#else
G_STATIC_ASSERT (sizeof (VteCell) == 8);
#endif

typedef union _VteIntCell {
	VteCell cell;
	struct VTE_GNUC_PACKED {
		guint32 c;
		VTE_CELL_ATTR_UINT attr;
	} i;
} VteIntCell;
G_STATIC_ASSERT (sizeof (VteCell) == sizeof (VteIntCell));

static const VteIntCell basic_cell = {
	{
		0,
		{
			0, /* fragment */
			1, /* columns */
			0, /* bold */
			0, /* italic */
			VTE_DEF_FG, /* fore */
			VTE_DEF_BG, /* back */

			0, /* standout */
			0, /* underline */
			0, /* strikethrough */

			0, /* reverse */
			0, /* blink */
			0, /* half */

			0  /* invisible */
		}
	}
};


/*
 * VteRowAttr: A single row's attributes
 */

typedef struct _VteRowAttr {
	guint8 soft_wrapped: 1;
} VteRowAttr;
G_STATIC_ASSERT (sizeof (VteRowAttr) == 1);

/*
 * VteRowData: A single row's data
 */

typedef struct _VteRowData {
	VteCell *cells;
	guint16 len;
	VteRowAttr attr;
} VteRowData;


#define _vte_row_data_length(__row)			((__row)->len + 0)

static inline const VteCell *
_vte_row_data_get (const VteRowData *row, gulong col)
{
	if (G_UNLIKELY (row->len <= col))
		return NULL;

	return &row->cells[col];
}

static inline VteCell *
_vte_row_data_get_writable (VteRowData *row, gulong col)
{
	if (G_UNLIKELY (row->len <= col))
		return NULL;

	return &row->cells[col];
}

void _vte_row_data_init (VteRowData *row);
void _vte_row_data_clear (VteRowData *row);
void _vte_row_data_fini (VteRowData *row);
void _vte_row_data_insert (VteRowData *row, gulong col, const VteCell *cell);
void _vte_row_data_append (VteRowData *row, const VteCell *cell);
void _vte_row_data_remove (VteRowData *row, gulong col);
void _vte_row_data_fill (VteRowData *row, const VteCell *cell, gulong len);
void _vte_row_data_shrink (VteRowData *row, gulong max_len);


G_END_DECLS

#endif
