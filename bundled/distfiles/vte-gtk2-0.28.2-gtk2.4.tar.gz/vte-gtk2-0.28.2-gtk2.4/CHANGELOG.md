# Changelog

All notable user-visible changes to the maintained GTK2 fork are documented
in this file. The project follows the structure of Keep a Changelog. Fork
release numbers retain the upstream `0.28.2` base for clarity.

Refactoring and test-only work is omitted unless it changes compatibility or
the supported build matrix.

## [Unreleased]

### Fixed

- Freed Unix98 PTY slave names after each session and on partial PTY setup
  failures, removing a 1 KiB leak per terminal session.

## [0.28.2-gtk2.4] - 2026-09-12

### Added

- Added SGR 3/23 italic text rendering with regular, bold, italic, and
  bold-italic Pango font variants.
- Added opt-in SGR 38/48 truecolor support through `--enable-truecolor`.
  The default keeps the compact legacy cell layout; the enabled variant
  preserves exact RGB values through rendering and text attributes.
- Added pixel-level Xvfb coverage for italic rendering and exact truecolor
  foreground/background attributes.

### Changed

- Kept a complete visible screen writable in memory, avoiding temporary-file
  paging solely because a terminal is taller than the historical ring size.
- Cached private scrollback stream lengths to avoid redundant `SEEK_END`
  operations, and reused existing string storage when serializing rows.
- Extended scrollback regression coverage to terminals taller than the
  historical 32-row writable ring, frozen rows, stream page rotation,
  content export, and history truncation.

### Compatibility

- The default build retains the 8-byte private cell layout. Truecolor is an
  explicit build-time choice and uses a 12-byte private cell; neither profile
  changes public headers, exported symbols, or the `libvte.so.9` SONAME.
- Both profiles retain the VTE 0.0 public API and pass the 134-symbol ABI
  guard on glibc and musl.

## [0.28.2-gtk2.3] - 2026-09-12

### Added

- Added xterm `CSI 3 J` support for clearing saved scrollback lines without
  erasing the visible screen.
- Added DECSCUSR cursor-style control (`CSI Ps SP q`) for blinking and steady
  block, underline, and I-beam cursors while preserving application defaults.
- Added integration coverage for alternate-screen state, resets, resizing,
  scrollback, TAB/CJK cells, selection, cursor sequences, and regex matches.

### Fixed

- Kept the normal and alternate screen rings synchronized after programmatic
  resizes and scrollback-limit changes, including changes made while the
  alternate screen is visible.
- Preserved smart TABs when the cursor merely moves through them, retained a
  shorter TAB when its left part is overwritten, and replaced orphaned halves
  of double-width characters with spaces during overwrite, erase, delete, and
  right-edge insertion operations.
- Made the cursor occupy one cell while positioned inside a smart TAB instead
  of covering the TAB's full remaining width.
- Kept box-drawing and block-element characters aligned when the existing
  `VTE_CJK_WIDTH=wide` compatibility mode is enabled.
- Invalidated the complete width of TAB and wide-character cells while a
  rectangular selection changes or is cleared, preventing stale selection
  highlighting outside the directly changed columns.
- Finished a Shift-initiated selection in mouse-reporting mode even when
  Shift is released before button 1, and consistently invalidated the initial
  word or line selection.
- Preserved input following RIS and DECSTR reset sequences instead of dropping
  later bytes from the same terminal stream.
- Forced the scrollbar back to its rebuilt history position after a
  history-clearing reset, avoiding a rare stale display and adjustment value.
- Made IL and DL return the cursor to the first column, made origin mode home
  and clamp absolute row addressing to its scrolling region, and restored the
  default row/column semantics of VPA and HPA.
- Made standard and DEC cursor-position reports use rows relative to the
  scrolling region while origin mode is active.
- Made ESC E scroll at the bottom margin and made cursor movement, editing,
  erase, line-feed, reverse-index, cursor restore, and status reports cancel a
  pending autowrap from the visible rightmost column where xterm does so.
- Corrected cached regular-expression boundaries so matches adjacent to
  non-matching text remain discoverable by the legacy match API.
- Ensured that disabling cursor blinking leaves a visible cursor, and kept
  input-method preedit text visible near the right margin.

## [0.28.2-gtk2.2] - 2026-09-12

### Added

- Added xterm SGR mouse reporting mode 1006, including large terminal
  coordinates and distinct press, drag, and release reports.
- Added xterm focus reporting mode 1004, with an immediate initial state
  report and automatic reset to the compatibility default.
- Added PTY-backed Xvfb coverage for bracketed paste on the normal and
  alternate screens, newline conversion, and 64 KiB clipboard payloads.

### Fixed

- Made physical Alt keys reported through X11 Mod1 consistently use VTE's
  existing Meta handling, including `meta-sends-escape` behavior.
- Made Home and End, including keypad variants, emit deterministic xterm
  sequences in normal and application cursor modes and encode modifiers.
- Corrected Ctrl+Alt+Space to emit `ESC NUL` instead of losing the Control
  modifier and emitting `ESC Space`.
- Corrected modified F1 through F4 keys to emit valid xterm CSI sequences
  instead of malformed mixtures of SS3 and CSI parameters.
- Corrected modifier encoding for keypad arithmetic keys and keypad Enter;
  Meta+Enter now preserves carriage-return semantics instead of sending LF.
- Made bold, dim, and standout attributes preserve explicitly selected
  256-color foreground and background entries, matching xterm behavior.
- Applied palette changes made through OSC 4 immediately, including proper
  redraw and background invalidation for already visible terminal contents.

## [0.28.2-gtk2.1] - 2026-09-12

### Added

- Added a GTK2 smoke-test application using the public VTE 0.0 API.
- Added an Alpine packaging template for an isolated `/opt/gtk2` runtime.
- Added an ABI export check for `libvte.so.9`.
- Added deterministic stress coverage for both legacy escape-sequence
  matchers, including control bytes, NUL, incomplete prefixes, and Unicode.
- Added Xvfb integration coverage for split UTF-8, combining characters,
  clipboard copy, 256-color attributes, and PTY lifecycle.

### Fixed

- Made `make distcheck` validate the maintained GTK2 build instead of
  requiring an unrelated GTK3 development stack.
- Correctly handled embedded NUL bytes, empty buffers, and invalid multibyte
  input in the internal UTF-8 converter.
- Preserved incomplete UTF-8 input correctly when split across PTY reads,
  while rejecting an incomplete character interrupted by a control sequence
  instead of silently dropping bytes.
- Fixed a cached Pango font-context reference leak and fully initialized
  selection coordinates when resetting a terminal.
- Prevented a crash when match-checking APIs are called without an optional
  tag output pointer.
- Corrected an off-by-one error when ECH erases beyond the allocated part of
  a terminal row.
- Ensured that VTE configures the child PTY before an application-provided
  child setup callback.
- Reset an inherited SIGQUIT disposition before executing a PTY child, so the
  child receives normal terminal signal behavior even when its GTK2 parent
  ignores SIGQUIT.
- Restored builds with current GCC and GLib by correcting incompatible pointer
  types and unsafe formatting in internal code.
- Restored `ptsname_r()` detection and use on musl systems.
- Updated GNU platform detection files to recognize current musl targets.

### Security

- Limited CSI parameters and OSC/DCS string payloads to 4096 Unicode
  characters. Oversized commands are ignored through their terminator instead
  of growing pending input and parameter allocations without bound.
- Prevented signed integer overflow while parsing exceptionally long numeric
  CSI parameters; values saturate at the existing 65535 compatibility limit.
- Limited parser argument values and character repetitions to prevent
  resource exhaustion by malicious escape sequences (CVE-2012-2738).

### Compatibility

- Preserved the VTE 0.0 public API, the `vte` pkg-config module, and the
  `libvte.so.9` ABI from upstream VTE 0.28.2.
- Retained the legacy Python and `gnome-pty-helper` sources, while disabling
  them in the recommended minimal package profile.

## Upstream base: VTE 0.28.2 - 2011-08-28

- Imported the final stable release of the upstream VTE 0.28 series.
- Upstream source SHA256:
  `86cf0b81aa023fa93ed415653d51c96767f20b2d7334c893caba71e42654b0ae`.
- License: GNU Library General Public License version 2 or later
  (`LGPL-2.0-or-later`).
