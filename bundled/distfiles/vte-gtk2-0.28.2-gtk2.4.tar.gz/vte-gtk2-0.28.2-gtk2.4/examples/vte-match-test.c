#include <gtk/gtk.h>
#include <string.h>
#include <vte/vte.h>

static void
drain_main_context(void)
{
	int i;

	for (i = 0; i < 100; i++) {
		while (g_main_context_iteration(NULL, FALSE))
			;
		g_usleep(1000);
	}
}

static void
send_motion(GtkWidget *widget, gdouble x, gdouble y)
{
	GdkEvent *event;

	event = gdk_event_new(GDK_MOTION_NOTIFY);
	event->motion.window = g_object_ref(gtk_widget_get_window(widget));
	event->motion.send_event = TRUE;
	event->motion.time = GDK_CURRENT_TIME;
	event->motion.x = x;
	event->motion.y = y;
	event->motion.state = 0;
	event->motion.is_hint = FALSE;
	gtk_widget_event(widget, event);
	gdk_event_free(event);
	drain_main_context();
}

static gboolean
expect_match(VteTerminal *terminal, const char *name, glong column,
	     int expected_tag)
{
	char *match;
	int tag = -1;
	gboolean passed;

	match = vte_terminal_match_check(terminal, column, 0, &tag);
	passed = match != NULL && strcmp(match, "foo") == 0 &&
		 tag == expected_tag;
	if (!passed)
		g_printerr("%s: tag=%d, match=<%s>\n", name, tag,
			   match != NULL ? match : "(null)");
	g_free(match);
	return passed;
}

int
main(int argc, char **argv)
{
	GtkWidget *window;
	GtkWidget *widget;
	VteTerminal *terminal;
	GRegex *regex;
	GError *error = NULL;
	glong width, height;
	int tag;
	gboolean passed = TRUE;

	if (!gtk_init_check(&argc, &argv)) {
		g_printerr("a running X server is required\n");
		return 77;
	}

	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	widget = vte_terminal_new();
	terminal = VTE_TERMINAL(widget);
	vte_terminal_set_size(terminal, 8, 2);
	gtk_container_add(GTK_CONTAINER(window), widget);
	gtk_widget_show_all(window);

	regex = g_regex_new("foo", G_REGEX_OPTIMIZE, 0, &error);
	if (regex == NULL) {
		g_printerr("cannot compile test regex: %s\n", error->message);
		g_error_free(error);
		return 1;
	}
	tag = vte_terminal_match_add_gregex(terminal, regex, 0);
	g_regex_unref(regex);
	width = vte_terminal_get_char_width(terminal);
	height = vte_terminal_get_char_height(terminal);

	/* A no-match hover immediately after a match must not cache the match
	 * itself as part of the blank region. */
	vte_terminal_feed(terminal, "\033cfooX", -1);
	drain_main_context();
	send_motion(widget, width * 3.5, height * 0.5);
	passed &= expect_match(terminal, "match-before-blank", 2, tag);

	/* Exercise the other exclusive boundary as well. */
	vte_terminal_feed(terminal, "\033cXfoo", -1);
	drain_main_context();
	send_motion(widget, width * 0.5, height * 0.5);
	passed &= expect_match(terminal, "match-after-blank", 1, tag);

	gtk_widget_destroy(window);
	drain_main_context();
	return passed ? 0 : 1;
}
