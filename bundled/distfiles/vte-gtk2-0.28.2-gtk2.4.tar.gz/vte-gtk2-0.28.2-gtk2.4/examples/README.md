# GTK2 smoke test

`vte-gtk2-smoke.c` sprawdza kompilację starego publicznego API, tworzy widget
VTE i uruchamia `/bin/sh` w PTY. Po instalacji biblioteki:

```sh
make
./vte-gtk2-smoke
```

Jeżeli `vte.pc` jest pod `/opt/gtk2`, ustaw dla kompilacji:

```sh
PKG_CONFIG_PATH=/opt/gtk2/lib/pkgconfig make
```

Przy niestandardowym `libdir` dostosuj ścieżkę. Do uruchomienia trzeba też
udostępnić loaderowi `/opt/gtk2/lib` zgodnie ze wspólną polityką runtime i mieć
aktywny serwer X.

`vte-reset-stream-test` jest nieinteraktywnym testem resetu strumienia. Sprawdza,
że tekst po RIS nie ginie, a jawne wywołanie starego publicznego
`vte_terminal_reset()` nadal odrzuca oczekujące wejście oraz przywraca
scrollbar po wyczyszczeniu historii. Obejmuje też 80-wierszowy terminal bez
scrollbacku, aby wykryć utratę widocznych wierszy podczas powiększania
prywatnego ringu. Osobny przebieg 300 wierszy sprawdza zamrażanie, obrót stron,
zapis zawartości i skracanie plikowego scrollbacku. Po kompilacji uruchom:

```sh
./vte-reset-stream-test
```

Test zwraca 0 po sukcesie, 1 po błędzie i 77, gdy nie ma serwera X. W
bezgłowym środowisku build można go uruchomić przez Xvfb.

`vte-cell-fragment-test` sprawdza zachowanie TAB i znaków dwukolumnowych przy
ruchu kursora, nadpisywaniu, ECH, DCH, EL i wstawianiu przy prawej krawędzi.
`vte-pty-lifecycle-test` uruchamia krótkie procesy potomne i sprawdza rozmiar
PTY, status zakończenia, reset SIGQUIT, pojedynczą emisję `child-exited` oraz
sprzątnięcie dziecka po zniszczeniu widgetu. Sprawdza też dokładne odpowiedzi
standardowego i DEC DSR w trybie origin. `vte-paste-test` przesyła dane
przez rzeczywisty schowek X11 i PTY: sprawdza bracketed paste na normalnym
i alternatywnym ekranie, konwersję LF oraz bufor o rozmiarze 64 KiB.
`vte-unicode-color-test` sprawdza UTF-8 rozdzielone między odczytami,
znak łączący, CJK, pozycje atrybutów, kopiowanie przez schowek oraz kolory
palety 256 przy bold/dim i zmianie OSC 4. Dla biblioteki zbudowanej z
`--enable-truecolor` ustawienie `VTE_EXPECT_TRUECOLOR=1` rozszerza test o
dokładne wartości pierwszego planu i tła z SGR `38;2`/`48;2`.
`vte-selection-test` wykonuje
syntetyczny Ctrl-drag i sprawdza prostokątne kopiowanie obszaru przecinającego
znak CJK, a także zaznaczenie rozpoczęte przez Shift w trybie raportowania
myszy, gdy Shift zostaje puszczony przed przyciskiem. Testy automatyczne można
uruchomić razem przeciw zainstalowanej
bibliotece:

`vte-sequence-test` sprawdza zachowanie IL/DL, trybu origin, domyślnych
parametrów HPA/VPA, anulowania oczekującego autowrapu oraz przewijającego
wariantu NEL (`ESC E`). Nie włącza DECCOLM: historyczna polityka VTE 0.28
pozostawia zmianę rozmiaru aplikacji osadzającej widget.

`vte-match-test` sprawdza publiczne API `vte_terminal_match_*()` dla wyrażeń
GLib. Najpierw przesuwa wskaźnik na znak bez dopasowania tuż przed lub za
wynikiem, a następnie upewnia się, że cache pustego obszaru nie zasłonił
sąsiedniego dopasowania.

`vte-style-test` renderuje ten sam tekst stylem regularnym i SGR 3, sprawdza
różnicę pikseli oraz powrót do identycznego stylu regularnego po SGR 23.

```sh
make
xvfb-run -a make check
```

Biblioteka używana przez test musi mieć dostęp do swojego pliku
`share/vte/termcap-0.0/xterm`; samo ustawienie ścieżki do niezainstalowanego
pliku `.so` nie wystarcza do testowania sekwencji kursora.

## Ręczna kontrola klawiatury

W uruchomionym przykładzie można sprawdzić bajty wysyłane przez klawisze za
pomocą `od -An -t x1`. Dla domyślnej emulacji oczekiwane są między innymi:

| Klawisz | Sekwencja |
| --- | --- |
| Home | `ESC [ H` |
| End | `ESC [ F` |
| Ctrl+Home | `ESC [ 1 ; 5 H` |
| Alt+End | `ESC [ 1 ; 3 F` |
| Ctrl+Alt+Space | `ESC NUL` |
| Ctrl+F1 | `ESC [ 1 ; 5 P` |
| Alt+Enter | `ESC CR` |
| Ctrl+KP Enter, application keypad | `ESC O 5 M` |
| Alt+F4 | `ESC [ 1 ; 3 S` |

Po włączeniu trybu klawiszy kursora `printf '\033[?1h'` Home/End używają
odpowiednio `ESC O H` i `ESC O F`. `printf '\033[?1l'` przywraca tryb
normalny. AltGr nie jest traktowany jak Alt/Meta.

## Ręczna kontrola kształtu kursora

DECSCUSR używa `CSI Ps SP q`. W uruchomionym shellu można kolejno sprawdzić:

```sh
printf '\033[1 q'  # migający blok
printf '\033[2 q'  # stały blok
printf '\033[3 q'  # migające podkreślenie
printf '\033[4 q'  # stałe podkreślenie
printf '\033[5 q'  # migająca kreska pionowa
printf '\033[6 q'  # stała kreska pionowa
printf '\033[0 q'  # ustawienia aplikacji/GTK2
```

Reset terminala (`RIS` lub `DECSTR`) również przywraca ustawienia aplikacji.

## Ręczna kontrola czyszczenia historii

Sekwencja xterm `CSI 3 J` usuwa zapisane linie przewijania, ale pozostawia
bieżący ekran bez zmian. W uruchomionym przykładzie można zapełnić historię,
wyczyścić ją i spróbować przewinąć terminal w górę:

```sh
i=1
while [ "$i" -le 100 ]; do
    printf 'history %03d\n' "$i"
    i=$((i + 1))
done
printf '\033[3J'
```

Po ostatniej komendzie linie sprzed aktualnego ekranu nie powinny już być
dostępne. Test nie zmienia ustawienia pojemności scrollbacku.

## Ręczna kontrola szerokości CJK

Tryb zgodności z terminalami CJK pozostaje opt-in. Przykład należy uruchomić
z `VTE_CJK_WIDTH=wide`, a następnie wyświetlić mieszane znaki ramek i bloków:

```sh
printf '─╌╴█▐▖▟\n'
```

Wszystkie znaki z zakresu U+2500..U+259F powinny zajmować po dwie kolumny i
pozostać wyrównane. Bez tej zmiennej środowiskowej zachowują zwykłą szerokość
wynikającą z GLib; domyślna polityka nie została zmieniona.
