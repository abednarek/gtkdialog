#include <gtk/gtk.h>
#include <vte/vte.h>

static void
child_exited(VteTerminal *terminal, gpointer user_data)
{
	(void) terminal;
	(void) user_data;
	gtk_main_quit();
}

int
main(int argc, char **argv)
{
	GtkWidget *window;
	GtkWidget *terminal_widget;
	VteTerminal *terminal;
	GError *error = NULL;
	GPid child_pid = -1;
	char *child_argv[] = { (char *) "/bin/sh", NULL };

	gtk_init(&argc, &argv);

	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_window_set_title(GTK_WINDOW(window), "VTE GTK2 smoke test");
	gtk_window_set_default_size(GTK_WINDOW(window), 720, 420);

	terminal_widget = vte_terminal_new();
	terminal = VTE_TERMINAL(terminal_widget);
	gtk_container_add(GTK_CONTAINER(window), terminal_widget);

	g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);
	g_signal_connect(terminal, "child-exited", G_CALLBACK(child_exited), NULL);

	if (!vte_terminal_fork_command_full(terminal,
	                                    VTE_PTY_DEFAULT,
	                                    NULL,
	                                    child_argv,
	                                    NULL,
	                                    G_SPAWN_SEARCH_PATH,
	                                    NULL,
	                                    NULL,
	                                    &child_pid,
	                                    &error)) {
		g_printerr("cannot start /bin/sh: %s\n", error->message);
		g_error_free(error);
		return 1;
	}

	gtk_widget_show_all(window);
	gtk_main();
	return 0;
}
