#include <gtk/gtk.h>
#include <string.h>
#include <vte/vte.h>

static gboolean
select_all(VteTerminal *terminal, glong column, glong row, gpointer data)
{
	(void) terminal;
	(void) column;
	(void) row;
	(void) data;
	return TRUE;
}

static void
drain_main_context(void)
{
	int i;

	for (i = 0; i < 100; i++) {
		while (g_main_context_iteration(NULL, FALSE))
			;
		g_usleep(1000);
	}
}

int
main(int argc, char **argv)
{
	GtkWidget *window;
	GtkWidget *widget;
	GtkWidget *tall_widget;
	VteTerminal *terminal;
	VteTerminal *tall_terminal;
	GtkAdjustment *adjustment;
	GOutputStream *output;
	GError *error = NULL;
	char *text;
	char *contents;
	GString *tall_screen;
	gsize contents_size;
	int i;
	gboolean passed;

	if (!gtk_init_check(&argc, &argv)) {
		g_printerr("a running X server is required\n");
		return 77;
	}

	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	widget = vte_terminal_new();
	terminal = VTE_TERMINAL(widget);
	vte_terminal_set_size(terminal, 20, 3);
	vte_terminal_set_scrollback_lines(terminal, 20);
	gtk_container_add(GTK_CONTAINER(window), widget);
	gtk_widget_show_all(window);

	/* A history-clearing reset must return the public scrollbar to the top. */
	vte_terminal_feed(terminal,
			  "1\r\n2\r\n3\r\n4\r\n5\r\n6\r\n7\r\n8\r\n", -1);
	drain_main_context();
	adjustment = vte_terminal_get_adjustment(terminal);
	passed = gtk_adjustment_get_value(adjustment) > 0;

	/* Resizing and changing scrollback while the alternate screen is active
	 * must update both private rings without merging their contents. */
	vte_terminal_feed(terminal, "\033[?1049hALT-SCREEN", -1);
	drain_main_context();
	vte_terminal_set_scrollback_lines(terminal, 0);
	vte_terminal_set_size(terminal, 14, 4);
	drain_main_context();
	text = vte_terminal_get_text(terminal, select_all, NULL, NULL);
	passed &= strstr(text, "ALT-SCREEN") != NULL &&
		  strstr(text, "8") == NULL;
	if (!passed)
		g_printerr("unexpected alternate screen after resize: %s\n", text);
	g_free(text);

	vte_terminal_feed(terminal, "\033[?1049l", -1);
	drain_main_context();
	text = vte_terminal_get_text(terminal, select_all, NULL, NULL);
	passed &= strstr(text, "ALT-SCREEN") == NULL &&
		  strstr(text, "8") != NULL;
	if (!passed)
		g_printerr("unexpected normal screen after resize: %s\n", text);
	g_free(text);

	/* A screen taller than the historical 32-row writable ring must keep a
	 * complete visible screen intact while the in-memory ring grows. */
	/* Keep this terminal unrealized.  A window manager may resize a shown
	 * widget asynchronously and make a ring-size test depend on timing. */
	tall_widget = vte_terminal_new();
	tall_terminal = VTE_TERMINAL(tall_widget);
	vte_terminal_set_size(tall_terminal, 20, 80);
	vte_terminal_set_scrollback_lines(tall_terminal, 0);
	tall_screen = g_string_new(NULL);
	for (i = 0; i < 80; i++) {
		g_string_append_printf(tall_screen, "row-%03d", i);
		if (i != 79)
			g_string_append(tall_screen, "\r\n");
	}
	vte_terminal_feed(tall_terminal, tall_screen->str, tall_screen->len);
	g_string_free(tall_screen, TRUE);
	drain_main_context();
	text = vte_terminal_get_text(tall_terminal, select_all, NULL, NULL);
	if (strstr(text, "row-000") == NULL || strstr(text, "row-079") == NULL) {
		passed = FALSE;
		g_printerr("tall in-memory screen lost visible rows: %s\n", text);
	}
	g_free(text);

	/* Exercise frozen rows, two-page file streams and truncation through the
	 * public APIs.  This also verifies the private cached stream lengths. */
	vte_terminal_set_size(tall_terminal, 20, 5);
	vte_terminal_set_scrollback_lines(tall_terminal, 200);
	vte_terminal_reset(tall_terminal, TRUE, TRUE);
	tall_screen = g_string_new(NULL);
	for (i = 0; i < 300; i++) {
		g_string_append_printf(tall_screen, "history-%03d", i);
		if (i != 299)
			g_string_append(tall_screen, "\r\n");
	}
	vte_terminal_feed(tall_terminal, tall_screen->str, tall_screen->len);
	g_string_free(tall_screen, TRUE);
	drain_main_context();
	output = g_memory_output_stream_new_resizable();
	if (!vte_terminal_write_contents(tall_terminal, output,
			VTE_TERMINAL_WRITE_DEFAULT, NULL, &error) ||
	    !g_output_stream_close(output, NULL, &error)) {
		passed = FALSE;
		g_printerr("could not write frozen scrollback: %s\n",
			   error != NULL ? error->message : "unknown error");
		g_clear_error(&error);
	} else {
		contents_size = g_memory_output_stream_get_data_size(
				G_MEMORY_OUTPUT_STREAM(output));
		contents = g_strndup(g_memory_output_stream_get_data(
				G_MEMORY_OUTPUT_STREAM(output)), contents_size);
		if (strstr(contents, "history-000") != NULL ||
		    strstr(contents, "history-150") == NULL ||
		    strstr(contents, "history-299") == NULL) {
			passed = FALSE;
			g_printerr("unexpected frozen scrollback contents\n");
		}
		g_free(contents);
	}
	g_object_unref(output);

	vte_terminal_set_scrollback_lines(tall_terminal, 10);
	text = vte_terminal_get_text(tall_terminal, select_all, NULL, NULL);
	if (strstr(text, "history-150") != NULL ||
	    strstr(text, "history-299") == NULL) {
		passed = FALSE;
		g_printerr("scrollback truncation retained the wrong rows\n");
	}
	g_free(text);
	g_object_unref(tall_widget);

	vte_terminal_reset(terminal, TRUE, TRUE);
	drain_main_context();
	passed &= gtk_adjustment_get_value(adjustment) == 0;
	if (!passed)
		g_printerr("reset adjustment value: %.0f\n",
			   gtk_adjustment_get_value(adjustment));

	/* The public API retains its documented input-discarding behavior. */
	vte_terminal_feed(terminal, "discarded", -1);
	vte_terminal_reset(terminal, TRUE, TRUE);

	/* RIS clears the screen; neither reset may consume following text. */
	vte_terminal_feed(terminal,
			  "before\r\n\033cafter-ris\r\n\033[!pafter-decstr\r\n",
			  -1);
	drain_main_context();

	text = vte_terminal_get_text(terminal, select_all, NULL, NULL);
	passed &= strstr(text, "after-ris") != NULL &&
		 strstr(text, "after-decstr") != NULL &&
		 strstr(text, "before") == NULL &&
		 strstr(text, "discarded") == NULL;
	if (!passed)
		g_printerr("unexpected terminal contents: %s\n", text);
	g_free(text);
	gtk_widget_destroy(window);

	return passed ? 0 : 1;
}
