#include <gtk/gtk.h>
#include <string.h>
#include <vte/vte.h>

static void
drain_main_context(void)
{
	int i;

	for (i = 0; i < 100; i++) {
		while (g_main_context_iteration(NULL, FALSE))
			;
		g_usleep(1000);
	}
}

static gboolean
send_button(GtkWidget *widget, GdkEventType type, guint button,
	    gdouble x, gdouble y, GdkModifierType state)
{
	GdkEvent *event;
	gboolean handled;

	event = gdk_event_new(type);
	event->button.window = g_object_ref(gtk_widget_get_window(widget));
	event->button.send_event = TRUE;
	event->button.time = GDK_CURRENT_TIME;
	event->button.x = x;
	event->button.y = y;
	event->button.state = state;
	event->button.button = button;
	handled = gtk_widget_event(widget, event);
	gdk_event_free(event);
	return handled;
}

static gboolean
send_motion(GtkWidget *widget, gdouble x, gdouble y, GdkModifierType state)
{
	GdkEvent *event;
	gboolean handled;

	event = gdk_event_new(GDK_MOTION_NOTIFY);
	event->motion.window = g_object_ref(gtk_widget_get_window(widget));
	event->motion.send_event = TRUE;
	event->motion.time = GDK_CURRENT_TIME;
	event->motion.x = x;
	event->motion.y = y;
	event->motion.state = state;
	event->motion.is_hint = FALSE;
	handled = gtk_widget_event(widget, event);
	gdk_event_free(event);
	return handled;
}

int
main(int argc, char **argv)
{
	GtkWidget *window;
	GtkWidget *widget;
	VteTerminal *terminal;
	GtkClipboard *primary;
	char *selected;
	glong width, height;
	gdouble start_x, start_y, end_x, end_y;
	gboolean handled;
	gboolean passed;

	if (!gtk_init_check(&argc, &argv)) {
		g_printerr("a running X server is required\n");
		return 77;
	}

	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	widget = vte_terminal_new();
	terminal = VTE_TERMINAL(widget);
	vte_terminal_set_size(terminal, 10, 3);
	gtk_container_add(GTK_CONTAINER(window), widget);
	gtk_widget_show_all(window);
	vte_terminal_feed(terminal,
		"\033cA\347\225\214CD\r\n12345",
		-1);
	drain_main_context();

	width = vte_terminal_get_char_width(terminal);
	height = vte_terminal_get_char_height(terminal);
	start_x = width * 1.5;
	start_y = height * 0.5;
	end_x = width * 3.5;
	end_y = height * 1.5;

	handled = send_button(widget, GDK_BUTTON_PRESS, 1,
			      start_x, start_y, GDK_CONTROL_MASK);
	handled &= send_motion(widget, end_x, end_y,
			       GDK_CONTROL_MASK | GDK_BUTTON1_MASK);
	handled &= send_button(widget, GDK_BUTTON_RELEASE, 1,
			       end_x, end_y, GDK_CONTROL_MASK);
	drain_main_context();

	primary = gtk_widget_get_clipboard(widget, GDK_SELECTION_PRIMARY);
	selected = gtk_clipboard_wait_for_text(primary);
	passed = handled && selected != NULL &&
		 strcmp(selected, "\347\225\214C\n234\n") == 0;
	if (!passed)
		g_printerr("rectangular selection: handled=%d, selected=<%s>\n",
			   handled, selected != NULL ? selected : "(null)");

	g_free(selected);

	/* Applications using mouse tracking require Shift to start a local
	 * selection.  Releasing Shift before button 1 must still finish and copy
	 * that selection rather than leaving input processing paused. */
	gtk_clipboard_clear(primary);
	vte_terminal_feed(terminal, "\033cABCDE\033[?1000h", -1);
	drain_main_context();
	start_x = width * 0.5;
	end_x = width * 2.5;
	handled = send_button(widget, GDK_BUTTON_PRESS, 1,
			      start_x, start_y, GDK_SHIFT_MASK);
	handled &= send_motion(widget, end_x, start_y,
			       GDK_SHIFT_MASK | GDK_BUTTON1_MASK);
	handled &= send_button(widget, GDK_BUTTON_RELEASE, 1,
			       end_x, start_y, 0);
	drain_main_context();
	selected = gtk_clipboard_wait_for_text(primary);
	if (!handled || selected == NULL || strcmp(selected, "ABC") != 0) {
		g_printerr("shift-release selection: handled=%d, selected=<%s>\n",
			   handled, selected != NULL ? selected : "(null)");
		passed = FALSE;
	}
	g_free(selected);

	gtk_widget_destroy(window);
	drain_main_context();
	return passed ? 0 : 1;
}
