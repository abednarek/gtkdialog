#include <errno.h>
#include <gtk/gtk.h>
#include <signal.h>
#include <string.h>
#include <sys/wait.h>
#include <termios.h>
#include <unistd.h>
#include <vte/vte.h>

typedef struct {
	GMainLoop *loop;
	int exit_status;
	int signal_count;
	gboolean timed_out;
} ChildState;

static gboolean
select_all(VteTerminal *terminal, glong column, glong row, gpointer data)
{
	(void) terminal;
	(void) column;
	(void) row;
	(void) data;
	return TRUE;
}

static gboolean
timeout_cb(gpointer data)
{
	ChildState *state = data;

	state->timed_out = TRUE;
	g_main_loop_quit(state->loop);
	return FALSE;
}

static void
child_exited_cb(VteTerminal *terminal, gpointer data)
{
	ChildState *state = data;

	state->exit_status = vte_terminal_get_child_exit_status(terminal);
	state->signal_count++;
	g_main_loop_quit(state->loop);
}

static gboolean
run_child(char **child_argv, glong columns, glong rows,
	  int *exit_status, char **contents)
{
	GtkWidget *window;
	GtkWidget *widget;
	VteTerminal *terminal;
	ChildState state = { NULL, 0, 0, FALSE };
	GError *error = NULL;
	GPid child_pid = -1;
	guint timeout_id;
	gboolean passed;

	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	widget = vte_terminal_new();
	terminal = VTE_TERMINAL(widget);
	gtk_container_add(GTK_CONTAINER(window), widget);
	vte_terminal_set_size(terminal, columns, rows);
	gtk_widget_show_all(window);

	state.loop = g_main_loop_new(NULL, FALSE);
	g_signal_connect(terminal, "child-exited",
			 G_CALLBACK(child_exited_cb), &state);
	passed = vte_terminal_fork_command_full(terminal, VTE_PTY_DEFAULT,
						NULL, child_argv, NULL,
						G_SPAWN_SEARCH_PATH,
						NULL, NULL, &child_pid, &error);
	if (!passed) {
		g_printerr("cannot start child: %s\n", error->message);
		g_error_free(error);
		g_main_loop_unref(state.loop);
		gtk_widget_destroy(window);
		return FALSE;
	}

	/* Exercise an application-requested resize after the PTY is attached. */
	vte_terminal_set_size(terminal, columns, rows);
	timeout_id = g_timeout_add_seconds(5, timeout_cb, &state);
	g_main_loop_run(state.loop);
	if (!state.timed_out)
		g_source_remove(timeout_id);

	while (g_main_context_iteration(NULL, FALSE))
		;
	if (contents != NULL)
		*contents = vte_terminal_get_text(terminal, select_all, NULL, NULL);
	if (exit_status != NULL)
		*exit_status = state.exit_status;

	passed = !state.timed_out && state.signal_count == 1;
	if (!passed)
		g_printerr("child lifecycle: timeout=%d, child-exited count=%d\n",
			   state.timed_out, state.signal_count);

	g_main_loop_unref(state.loop);
	gtk_widget_destroy(window);
	while (g_main_context_iteration(NULL, FALSE))
		;
	return passed;
}

static gboolean
read_exact(int fd, char *buffer, size_t length)
{
	size_t offset = 0;

	while (offset < length) {
		ssize_t count = read(fd, buffer + offset, length - offset);
		if (count > 0) {
			offset += count;
			continue;
		}
		if (count < 0 && errno == EINTR)
			continue;
		return FALSE;
	}
	return TRUE;
}

static int
run_dsr_child(void)
{
	static const char query[] =
		"\033c\033[3;5r\033[?6h\033[2;4H\033[6n";
	static const char dec_query[] = "\033[?6n";
	static const char expected[] = "\033[2;4R";
	static const char dec_expected[] = "\033[?2;4R";
	struct termios attributes;
	char response[sizeof(dec_expected) - 1];

	if (tcgetattr(STDIN_FILENO, &attributes) != 0)
		return 2;
	attributes.c_lflag &= ~(ECHO | ICANON);
	attributes.c_iflag &= ~(ICRNL | INLCR);
	attributes.c_cc[VMIN] = 1;
	attributes.c_cc[VTIME] = 0;
	if (tcsetattr(STDIN_FILENO, TCSANOW, &attributes) != 0)
		return 3;

	if (write(STDOUT_FILENO, query, sizeof(query) - 1) !=
	    (ssize_t) sizeof(query) - 1 ||
	    !read_exact(STDIN_FILENO, response, sizeof(expected) - 1) ||
	    memcmp(response, expected, sizeof(expected) - 1) != 0)
		return 4;
	if (write(STDOUT_FILENO, dec_query, sizeof(dec_query) - 1) !=
	    (ssize_t) sizeof(dec_query) - 1 ||
	    !read_exact(STDIN_FILENO, response, sizeof(dec_expected) - 1) ||
	    memcmp(response, dec_expected, sizeof(dec_expected) - 1) != 0)
		return 5;

	return 0;
}

static gboolean
test_origin_mode_dsr(const char *program)
{
	char *argv[] = { (char *) program, (char *) "--dsr-child", NULL };
	int status = 0;
	gboolean passed;

	passed = run_child(argv, 10, 6, &status, NULL);
	passed &= WIFEXITED(status) && WEXITSTATUS(status) == 0;
	if (!passed)
		g_printerr("origin-mode DSR child status: %d\n", status);
	return passed;
}

static gboolean
test_resize_and_exit_status(void)
{
	char *argv[] = { (char *) "/bin/sh", (char *) "-c",
		(char *) "sleep 1; stty size; exit 23", NULL };
	char *contents = NULL;
	int status = 0;
	gboolean passed;

	passed = run_child(argv, 97, 31, &status, &contents);
	passed = passed && WIFEXITED(status) && WEXITSTATUS(status) == 23 &&
		 strstr(contents, "31 97") != NULL;
	if (!passed)
		g_printerr("resize/status: status=%d, contents=<%s>\n",
			   status, contents != NULL ? contents : "(null)");
	g_free(contents);
	return passed;
}

static gboolean
test_sigquit_reset(const char *program)
{
	char *argv[] = { (char *) program, (char *) "--raise-sigquit", NULL };
	struct sigaction ignore_action;
	struct sigaction old_action;
	int status = 0;
	gboolean passed;

	memset(&ignore_action, 0, sizeof(ignore_action));
	ignore_action.sa_handler = SIG_IGN;
	sigemptyset(&ignore_action.sa_mask);
	if (sigaction(SIGQUIT, &ignore_action, &old_action) != 0) {
		g_printerr("cannot ignore SIGQUIT in parent: %s\n", g_strerror(errno));
		return FALSE;
	}

	passed = run_child(argv, 80, 24, &status, NULL);
	sigaction(SIGQUIT, &old_action, NULL);
	passed = passed && WIFSIGNALED(status) && WTERMSIG(status) == SIGQUIT;
	if (!passed)
		g_printerr("SIGQUIT disposition leaked to child, status=%d\n", status);
	return passed;
}

static gboolean
test_destroy_reaps_child(void)
{
	GtkWidget *window;
	GtkWidget *widget;
	VteTerminal *terminal;
	char *argv[] = { (char *) "/bin/sh", (char *) "-c",
		(char *) "sleep 2", NULL };
	GError *error = NULL;
	GPid child_pid = -1;
	gint64 deadline;
	int status;

	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	widget = vte_terminal_new();
	terminal = VTE_TERMINAL(widget);
	gtk_container_add(GTK_CONTAINER(window), widget);
	gtk_widget_show_all(window);
	if (!vte_terminal_fork_command_full(terminal, VTE_PTY_DEFAULT, NULL,
					    argv, NULL, G_SPAWN_SEARCH_PATH,
					    NULL, NULL, &child_pid, &error)) {
		g_printerr("cannot start disposable child: %s\n", error->message);
		g_error_free(error);
		gtk_widget_destroy(window);
		return FALSE;
	}

	gtk_widget_destroy(window);
	deadline = g_get_monotonic_time() + 5 * G_TIME_SPAN_SECOND;
	while (g_get_monotonic_time() < deadline && kill(child_pid, 0) == 0) {
		g_main_context_iteration(NULL, FALSE);
		g_usleep(1000);
	}
	while (g_main_context_iteration(NULL, FALSE))
		;

	errno = 0;
	if (waitpid(child_pid, &status, WNOHANG) == -1 && errno == ECHILD)
		return TRUE;

	g_printerr("destroyed terminal did not reap child %ld\n", (long) child_pid);
	return FALSE;
}

int
main(int argc, char **argv)
{
	gboolean passed = TRUE;

	/* Execute a real child process rather than a shell: BusyBox ash ignores
	 * SIGQUIT for non-interactive commands independently of inherited state. */
	if (argc == 2 && strcmp(argv[1], "--raise-sigquit") == 0) {
		raise(SIGQUIT);
		return 42;
	}
	if (argc == 2 && strcmp(argv[1], "--dsr-child") == 0)
		return run_dsr_child();

	if (!gtk_init_check(&argc, &argv)) {
		g_printerr("a running X server is required\n");
		return 77;
	}

	passed &= test_resize_and_exit_status();
	passed &= test_sigquit_reset(argv[0]);
	passed &= test_origin_mode_dsr(argv[0]);
	passed &= test_destroy_reaps_child();
	return passed ? 0 : 1;
}
