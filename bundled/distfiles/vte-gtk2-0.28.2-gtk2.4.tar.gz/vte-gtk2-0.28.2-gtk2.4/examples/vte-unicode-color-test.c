#include <gtk/gtk.h>
#include <string.h>
#include <vte/vte.h>

static gboolean
select_all(VteTerminal *terminal, glong column, glong row, gpointer data)
{
	(void) terminal;
	(void) column;
	(void) row;
	(void) data;
	return TRUE;
}

static void
drain_main_context(void)
{
	int i;

	for (i = 0; i < 100; i++) {
		while (g_main_context_iteration(NULL, FALSE))
			;
		g_usleep(1000);
	}
}

static VteTerminal *
new_terminal(GtkWidget **window_out)
{
	GtkWidget *window;
	GtkWidget *widget;
	VteTerminal *terminal;

	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	widget = vte_terminal_new();
	terminal = VTE_TERMINAL(widget);
	vte_terminal_set_size(terminal, 20, 2);
	gtk_container_add(GTK_CONTAINER(window), widget);
	gtk_widget_show_all(window);
	vte_terminal_feed(terminal, "\033c", -1);
	drain_main_context();
	*window_out = window;
	return terminal;
}

static gboolean
same_color(const GdkColor *a, const GdkColor *b)
{
	return a->red == b->red && a->green == b->green && a->blue == b->blue;
}

static gboolean
test_split_utf8_and_copy(void)
{
	const char expected[] = "\342\202\254e\314\201-\347\225\214";
	GtkWidget *window;
	VteTerminal *terminal;
	GArray *attributes;
	VteCharAttributes *attr;
	GtkClipboard *clipboard;
	char *clipboard_text;
	char *text;
	glong column, row;
	gboolean passed;

	terminal = new_terminal(&window);
	vte_terminal_feed(terminal, "\342\202", 2);
	drain_main_context();
	vte_terminal_feed(terminal, "\254e\314\201-\347\225\214", 8);
	drain_main_context();

	attributes = g_array_new(FALSE, FALSE, sizeof(VteCharAttributes));
	text = vte_terminal_get_text_range(terminal, 0, 0, 0, 19,
					   select_all, NULL, attributes);
	attr = (VteCharAttributes *) attributes->data;
	vte_terminal_get_cursor_position(terminal, &column, &row);
	passed = g_str_has_prefix(text, expected) &&
		 attributes->len >= strlen(expected) &&
		 attr[0].column == 0 && attr[1].column == 0 && attr[2].column == 0 &&
		 attr[3].column == 1 && attr[4].column == 1 && attr[5].column == 1 &&
		 attr[6].column == 2 &&
		 attr[7].column == 3 && attr[8].column == 3 && attr[9].column == 3 &&
		 column == 5 && row == 0;
	if (!passed)
		g_printerr("UTF-8 extraction: text=<%s>, bytes=%u, cursor=%ld,%ld\n",
			   text, attributes->len, column, row);

	vte_terminal_select_all(terminal);
	vte_terminal_copy_clipboard(terminal);
	drain_main_context();
	clipboard = gtk_widget_get_clipboard(GTK_WIDGET(terminal),
					     GDK_SELECTION_CLIPBOARD);
	clipboard_text = gtk_clipboard_wait_for_text(clipboard);
	passed = passed && clipboard_text != NULL &&
		 strstr(clipboard_text, expected) != NULL;
	if (clipboard_text == NULL || strstr(clipboard_text, expected) == NULL)
		g_printerr("UTF-8 clipboard copy did not preserve the selected text\n");

	g_free(clipboard_text);
	g_free(text);
	g_array_free(attributes, TRUE);
	gtk_widget_destroy(window);
	drain_main_context();
	return passed;
}

static gboolean
test_palette_attributes(void)
{
	GtkWidget *window;
	VteTerminal *terminal;
	GdkColor palette[256];
	GdkColor changed = { 0, 0x1111, 0x2222, 0x3333 };
	GArray *attributes;
	VteCharAttributes *attr;
	char *text;
	int i;
	gboolean passed;

	terminal = new_terminal(&window);
	for (i = 0; i < 256; i++) {
		palette[i].pixel = 0;
		palette[i].red = i * 257;
		palette[i].green = (255 - i) * 257;
		palette[i].blue = (i ^ 0x55) * 257;
	}
	vte_terminal_set_colors(terminal, NULL, NULL, palette, 255);
	vte_terminal_feed(terminal,
		"\033[38;5;200mA\033[1mB\033[2mC"
		"\033[22;48;5;100mD"
		"\033]4;200;rgb:1111/2222/3333\007",
		-1);
	drain_main_context();

	attributes = g_array_new(FALSE, FALSE, sizeof(VteCharAttributes));
	text = vte_terminal_get_text_range(terminal, 0, 0, 0, 19,
					   select_all, NULL, attributes);
	attr = (VteCharAttributes *) attributes->data;
	passed = g_str_has_prefix(text, "ABCD") && attributes->len >= 4 &&
		 same_color(&attr[0].fore, &changed) &&
		 same_color(&attr[1].fore, &changed) &&
		 same_color(&attr[2].fore, &changed) &&
		 same_color(&attr[3].back, &palette[100]);
	if (!passed)
		g_printerr("palette attributes did not survive SGR/OSC changes: <%s>; "
			   "fore=%04x/%04x/%04x,%04x/%04x/%04x,%04x/%04x/%04x "
			   "back=%04x/%04x/%04x\n",
			   text,
			   attr[0].fore.red, attr[0].fore.green, attr[0].fore.blue,
			   attr[1].fore.red, attr[1].fore.green, attr[1].fore.blue,
			   attr[2].fore.red, attr[2].fore.green, attr[2].fore.blue,
			   attr[3].back.red, attr[3].back.green, attr[3].back.blue);

	g_free(text);
	g_array_free(attributes, TRUE);
	gtk_widget_destroy(window);
	drain_main_context();
	return passed;
}

static gboolean
test_truecolor_attributes(void)
{
	GtkWidget *window;
	VteTerminal *terminal;
	GArray *attributes;
	VteCharAttributes *attr;
	char *text;
	gboolean passed;

	terminal = new_terminal(&window);
	vte_terminal_feed(terminal,
		"\033[38;2;18;52;86;48;2;101;67;33mT", -1);
	drain_main_context();

	attributes = g_array_new(FALSE, FALSE, sizeof(VteCharAttributes));
	text = vte_terminal_get_text_range(terminal, 0, 0, 0, 19,
					   select_all, NULL, attributes);
	attr = (VteCharAttributes *) attributes->data;
	passed = g_str_has_prefix(text, "T") && attributes->len >= 1 &&
		 attr[0].fore.red == 18 * 257 &&
		 attr[0].fore.green == 52 * 257 &&
		 attr[0].fore.blue == 86 * 257 &&
		 attr[0].back.red == 101 * 257 &&
		 attr[0].back.green == 67 * 257 &&
		 attr[0].back.blue == 33 * 257;
	if (!passed)
		g_printerr("truecolor attributes were not preserved: <%s>; "
			   "fore=%04x/%04x/%04x back=%04x/%04x/%04x\n",
			   text,
			   attr[0].fore.red, attr[0].fore.green, attr[0].fore.blue,
			   attr[0].back.red, attr[0].back.green, attr[0].back.blue);

	g_free(text);
	g_array_free(attributes, TRUE);
	gtk_widget_destroy(window);
	drain_main_context();
	return passed;
}

int
main(int argc, char **argv)
{
	gboolean passed = TRUE;

	if (!gtk_init_check(&argc, &argv)) {
		g_printerr("a running X server is required\n");
		return 77;
	}

	passed &= test_split_utf8_and_copy();
	passed &= test_palette_attributes();
	if (g_getenv("VTE_EXPECT_TRUECOLOR") != NULL)
		passed &= test_truecolor_attributes();
	return passed ? 0 : 1;
}
