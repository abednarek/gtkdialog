#include <gtk/gtk.h>
#include <string.h>
#include <vte/vte.h>

static gboolean
select_all(VteTerminal *terminal, glong column, glong row, gpointer data)
{
	(void) terminal;
	(void) column;
	(void) row;
	(void) data;
	return TRUE;
}

static void
drain_main_context(void)
{
	int i;

	for (i = 0; i < 100; i++) {
		while (g_main_context_iteration(NULL, FALSE))
			;
		g_usleep(1000);
	}
}

static gboolean
run_case(const char *name, glong columns, const char *input,
	 const char *expected)
{
	GtkWidget *window;
	GtkWidget *widget;
	VteTerminal *terminal;
	char *text;
	gboolean passed;
	gsize length;

	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	widget = vte_terminal_new();
	terminal = VTE_TERMINAL(widget);
	vte_terminal_set_size(terminal, columns, 2);
	gtk_container_add(GTK_CONTAINER(window), widget);
	gtk_widget_show_all(window);

	vte_terminal_feed(terminal, input, -1);
	drain_main_context();

	text = vte_terminal_get_text_range(terminal, 0, 0, 0, columns - 1,
					   select_all, NULL, NULL);
	length = strlen(text);
	if (length > 0 && text[length - 1] == '\n')
		text[length - 1] = '\0';

	passed = strcmp(text, expected) == 0;
	if (!passed)
		g_printerr("%s: expected <%s>, got <%s>\n", name, expected, text);

	g_free(text);
	gtk_widget_destroy(window);
	drain_main_context();
	return passed;
}

int
main(int argc, char **argv)
{
	gboolean passed = TRUE;

	if (!gtk_init_check(&argc, &argv)) {
		g_printerr("a running X server is required\n");
		return 77;
	}

	/* Moving through a smart tab must not alter the row. */
	passed &= run_case("tab-cursor-movement", 10,
			   "\033cA\tB\033[1;4H", "A\tB");

	/* Overwriting inside a tab keeps its right part as a shorter tab. */
	passed &= run_case("tab-overwrite", 10,
			   "\033cA\tB\033[1;4HX", "A  X\tB");

	/* Splitting a double-width character replaces its other half by space. */
	passed &= run_case("cjk-overwrite", 10,
			   "\033c\347\225\214AB\033[1;2HXZ", " XZB");
	passed &= run_case("cjk-erase", 10,
			   "\033cA\347\225\214B\033[1;3H\033[X", "A  B");
	passed &= run_case("cjk-delete", 10,
			   "\033cA\347\225\214B\033[1;3H\033[P", "A B");
	passed &= run_case("cjk-clear-right", 10,
			   "\033cA\347\225\214B\033[1;3H\033[K", "A ");
	passed &= run_case("cjk-clear-left", 10,
			   "\033cA\347\225\214B\033[1;3H\033[1K", "   B");
	passed &= run_case("cjk-clear-left-leading-half", 10,
			   "\033cA\347\225\214B\033[1;2H\033[1K", "   B");

	/* Insertion must not leave an orphaned CJK half at the right edge. */
	passed &= run_case("cjk-right-edge", 4,
			   "\033cAB\347\225\214\033[1;1H\033[@", " AB ");

	return passed ? 0 : 1;
}
