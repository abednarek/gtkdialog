#include <gtk/gtk.h>
#include <string.h>
#include <vte/vte.h>

static gboolean
select_all(VteTerminal *terminal, glong column, glong row, gpointer data)
{
	(void) terminal;
	(void) column;
	(void) row;
	(void) data;
	return TRUE;
}

static void
drain_main_context(void)
{
	int i;

	for (i = 0; i < 100; i++) {
		while (g_main_context_iteration(NULL, FALSE))
			;
		g_usleep(1000);
	}
}

static gboolean
expect_cursor(VteTerminal *terminal, const char *name,
	      glong expected_column, glong expected_row)
{
	glong column, row;

	drain_main_context();
	vte_terminal_get_cursor_position(terminal, &column, &row);
	if (column == expected_column && row == expected_row)
		return TRUE;

	g_printerr("%s: expected cursor %ld,%ld, got %ld,%ld\n",
		   name, expected_column, expected_row, column, row);
	return FALSE;
}

static gboolean
expect_row(VteTerminal *terminal, const char *name, glong row,
	   const char *expected)
{
	char *text;
	gsize length;
	gboolean passed;

	drain_main_context();
	text = vte_terminal_get_text_range(terminal, row, 0, row, 4,
					   select_all, NULL, NULL);
	length = strlen(text);
	if (length > 0 && text[length - 1] == '\n')
		text[length - 1] = '\0';
	passed = strcmp(text, expected) == 0;
	if (!passed)
		g_printerr("%s: expected <%s>, got <%s>\n", name,
			   expected, text);
	g_free(text);
	return passed;
}

static gboolean
test_line_operations(VteTerminal *terminal)
{
	gboolean passed = TRUE;

	vte_terminal_feed(terminal, "\033c\033[2;4H\033[L", -1);
	passed &= expect_cursor(terminal, "insert-lines", 0, 1);
	vte_terminal_feed(terminal, "\033c\033[2;4H\033[M", -1);
	passed &= expect_cursor(terminal, "delete-lines", 0, 1);
	return passed;
}

static gboolean
test_origin_mode(VteTerminal *terminal)
{
	gboolean passed = TRUE;

	vte_terminal_feed(terminal, "\033c\033[3;5r\033[?6h", -1);
	passed &= expect_cursor(terminal, "origin-home", 0, 2);
	vte_terminal_feed(terminal, "\033[99;4H", -1);
	passed &= expect_cursor(terminal, "origin-cup-clamp", 3, 4);
	vte_terminal_feed(terminal, "\033[d", -1);
	passed &= expect_cursor(terminal, "origin-vpa-default", 3, 2);
	vte_terminal_feed(terminal, "\033[`", -1);
	passed &= expect_cursor(terminal, "hpa-default", 0, 2);
	vte_terminal_feed(terminal, "\033[?6l", -1);
	passed &= expect_cursor(terminal, "origin-reset-home", 0, 0);
	return passed;
}

static gboolean
test_right_margin(VteTerminal *terminal)
{
	gboolean passed = TRUE;

	vte_terminal_feed(terminal, "\033cabcde\033[D", -1);
	passed &= expect_cursor(terminal, "right-margin-cub", 3, 0);
	vte_terminal_feed(terminal, "\033cabcde\033[A", -1);
	passed &= expect_cursor(terminal, "right-margin-cuu", 4, 0);
	vte_terminal_feed(terminal, "\033cabcde\033[B", -1);
	passed &= expect_cursor(terminal, "right-margin-cud", 4, 1);
	vte_terminal_feed(terminal, "\033cabcde\033[C", -1);
	passed &= expect_cursor(terminal, "right-margin-cuf", 4, 0);
	vte_terminal_feed(terminal, "\033cabcde\033[X", -1);
	passed &= expect_cursor(terminal, "right-margin-ech", 4, 0);
	passed &= expect_row(terminal, "right-margin-ech-text", 0, "abcd");
	vte_terminal_feed(terminal, "\033cabcde\033[P", -1);
	passed &= expect_cursor(terminal, "right-margin-dch", 4, 0);
	passed &= expect_row(terminal, "right-margin-dch-text", 0, "abcd");
	vte_terminal_feed(terminal, "\033cabcde\033[K", -1);
	passed &= expect_cursor(terminal, "right-margin-el", 4, 0);
	passed &= expect_row(terminal, "right-margin-el-text", 0, "abcd");
	vte_terminal_feed(terminal, "\033cabcde\0337\r\0338", -1);
	passed &= expect_cursor(terminal, "right-margin-restore", 4, 0);
	vte_terminal_feed(terminal, "\033cabcde\n", -1);
	passed &= expect_cursor(terminal, "right-margin-lf", 4, 1);
	vte_terminal_feed(terminal, "\033c\033[2;1Habcde\033M", -1);
	passed &= expect_cursor(terminal, "right-margin-ri", 4, 0);

	return passed;
}

static gboolean
test_next_line(VteTerminal *terminal)
{
	char *text;
	char *second;
	gboolean passed;

	/* Restrict scrolling to two middle rows so the test does not depend on
	 * the window manager accepting a resize after the widget is realised. */
	vte_terminal_feed(terminal,
			  "\033c\033[2;1H11111\r\n22222\033[2;3r"
			  "\033[3;1H\033EX", -1);
	drain_main_context();
	text = vte_terminal_get_text_range(terminal, 1, 0, 2, 4,
					   select_all, NULL, NULL);
	second = strstr(text, "22222");
	passed = strstr(text, "11111") == NULL && second != NULL &&
		 strstr(second, "X") != NULL;
	if (!passed)
		g_printerr("next-line scroll: unexpected contents <%s>\n", text);
	g_free(text);
	return passed;
}

int
main(int argc, char **argv)
{
	GtkWidget *window;
	GtkWidget *widget;
	VteTerminal *terminal;
	gboolean passed = TRUE;

	if (!gtk_init_check(&argc, &argv)) {
		g_printerr("a running X server is required\n");
		return 77;
	}

	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	widget = vte_terminal_new();
	terminal = VTE_TERMINAL(widget);
	vte_terminal_set_size(terminal, 5, 6);
	gtk_container_add(GTK_CONTAINER(window), widget);
	gtk_widget_show_all(window);

	passed &= test_line_operations(terminal);
	passed &= test_origin_mode(terminal);
	passed &= test_right_margin(terminal);
	passed &= test_next_line(terminal);

	gtk_widget_destroy(window);
	drain_main_context();
	return passed ? 0 : 1;
}
