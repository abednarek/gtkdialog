#include <ctype.h>
#include <gtk/gtk.h>
#include <string.h>
#include <vte/vte.h>

typedef struct {
	GMainLoop *loop;
	int exit_status;
	gboolean timed_out;
} ChildState;

static gboolean
select_all(VteTerminal *terminal, glong column, glong row, gpointer data)
{
	(void) terminal;
	(void) column;
	(void) row;
	(void) data;
	return TRUE;
}

static void
drain_main_context(void)
{
	int i;

	for (i = 0; i < 100; i++) {
		while (g_main_context_iteration(NULL, FALSE))
			;
		g_usleep(1000);
	}
}

static gboolean
wait_for_marker(VteTerminal *terminal, const char *marker)
{
	gint64 deadline = g_get_monotonic_time() + 5 * G_TIME_SPAN_SECOND;

	while (g_get_monotonic_time() < deadline) {
		char *contents;
		gboolean found;

		while (g_main_context_iteration(NULL, FALSE))
			;
		contents = vte_terminal_get_text(terminal, select_all, NULL, NULL);
		found = strstr(contents, marker) != NULL;
		g_free(contents);
		if (found)
			return TRUE;
		g_usleep(1000);
	}
	return FALSE;
}

static gboolean
timeout_cb(gpointer data)
{
	ChildState *state = data;

	state->timed_out = TRUE;
	g_main_loop_quit(state->loop);
	return FALSE;
}

static void
child_exited_cb(VteTerminal *terminal, gpointer data)
{
	ChildState *state = data;

	state->exit_status = vte_terminal_get_child_exit_status(terminal);
	g_main_loop_quit(state->loop);
}

static VteTerminal *
start_child(GtkWidget **window_out, ChildState *state, char **child_argv)
{
	GtkWidget *window;
	GtkWidget *widget;
	VteTerminal *terminal;
	GError *error = NULL;

	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	widget = vte_terminal_new();
	terminal = VTE_TERMINAL(widget);
	gtk_container_add(GTK_CONTAINER(window), widget);
	gtk_widget_show_all(window);
	vte_terminal_feed(terminal, "\033c", -1);
	drain_main_context();

	state->loop = g_main_loop_new(NULL, FALSE);
	state->exit_status = 0;
	state->timed_out = FALSE;
	g_signal_connect(terminal, "child-exited",
			 G_CALLBACK(child_exited_cb), state);
	if (!vte_terminal_fork_command_full(terminal, VTE_PTY_DEFAULT, NULL,
					    child_argv, NULL, G_SPAWN_SEARCH_PATH,
					    NULL, NULL, NULL, &error)) {
		g_printerr("cannot start paste child: %s\n", error->message);
		g_error_free(error);
		g_main_loop_unref(state->loop);
		gtk_widget_destroy(window);
		return NULL;
	}

	*window_out = window;
	return terminal;
}

static char *
wait_for_child(GtkWidget *window, VteTerminal *terminal, ChildState *state)
{
	guint timeout_id;
	char *contents;

	timeout_id = g_timeout_add_seconds(10, timeout_cb, state);
	g_main_loop_run(state->loop);
	if (!state->timed_out)
		g_source_remove(timeout_id);
	drain_main_context();
	contents = vte_terminal_get_text(terminal, select_all, NULL, NULL);
	g_main_loop_unref(state->loop);
	gtk_widget_destroy(window);
	drain_main_context();
	return contents;
}

static void
set_clipboard_text(VteTerminal *terminal, const char *text, gsize length)
{
	GtkClipboard *clipboard;

	clipboard = gtk_widget_get_clipboard(GTK_WIDGET(terminal),
					     GDK_SELECTION_CLIPBOARD);
	gtk_clipboard_set_text(clipboard, text, length);
}

static gboolean
test_bracketed_paste_per_screen(void)
{
	char *argv[] = { (char *) "/bin/sh", (char *) "-c",
		(char *) "stty -echo -icanon min 1; printf 'READY\\n'; od -An -v -t x1 -N 20", NULL };
	const char payload[] = "A\n\305\274";
	const char expected[] =
		"410ac5bc1b5b3230307e410ac5bc1b5b3230317e";
	GtkWidget *window;
	VteTerminal *terminal;
	ChildState state;
	GString *hex;
	char *contents;
	const char *p;
	gboolean passed;

	terminal = start_child(&window, &state, argv);
	if (terminal == NULL)
		return FALSE;
	if (!wait_for_marker(terminal, "READY")) {
		g_printerr("bracketed paste child did not become ready\n");
		gtk_widget_destroy(window);
		g_main_loop_unref(state.loop);
		return FALSE;
	}

	set_clipboard_text(terminal, payload, sizeof(payload) - 1);
	/* Normal screen: enabled.  Alternate screen: compatibility default. */
	vte_terminal_feed(terminal, "\033[?2004h\033[?1049h", -1);
	drain_main_context();
	vte_terminal_paste_clipboard(terminal);
	drain_main_context();
	vte_terminal_feed(terminal, "\033[?1049l", -1);
	drain_main_context();
	vte_terminal_paste_clipboard(terminal);

	contents = wait_for_child(window, terminal, &state);
	hex = g_string_new(NULL);
	for (p = contents; *p != '\0'; p++) {
		if (g_ascii_isxdigit(*p))
			g_string_append_c(hex, g_ascii_tolower(*p));
	}
	passed = !state.timed_out && g_str_has_suffix(hex->str, expected);
	if (!passed)
		g_printerr("bracketed paste: expected <%s>, got <%s> from <%s>\n",
			   expected, hex->str, contents);
	g_string_free(hex, TRUE);
	g_free(contents);
	return passed;
}

static gboolean
test_long_paste(void)
{
	char *argv[] = { (char *) "/bin/sh", (char *) "-c",
		(char *) "stty -echo -icanon min 1; printf 'READY\\n'; dd bs=1 count=65536 2>/dev/null | wc -c",
		NULL };
	GtkWidget *window;
	VteTerminal *terminal;
	ChildState state;
	char *payload;
	char *contents;
	gboolean passed;

	terminal = start_child(&window, &state, argv);
	if (terminal == NULL)
		return FALSE;
	if (!wait_for_marker(terminal, "READY")) {
		g_printerr("long paste child did not become ready\n");
		gtk_widget_destroy(window);
		g_main_loop_unref(state.loop);
		return FALSE;
	}

	payload = g_malloc(65536);
	memset(payload, 'x', 65536);
	set_clipboard_text(terminal, payload, 65536);
	vte_terminal_paste_clipboard(terminal);
	g_free(payload);

	contents = wait_for_child(window, terminal, &state);
	passed = !state.timed_out && strstr(contents, "65536") != NULL;
	if (!passed)
		g_printerr("long paste: unexpected contents <%s>\n", contents);
	g_free(contents);
	return passed;
}

int
main(int argc, char **argv)
{
	gboolean passed = TRUE;

	if (!gtk_init_check(&argc, &argv)) {
		g_printerr("a running X server is required\n");
		return 77;
	}

	passed &= test_bracketed_paste_per_screen();
	passed &= test_long_paste();
	return passed ? 0 : 1;
}
