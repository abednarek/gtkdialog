#include <gtk/gtk.h>
#include <string.h>
#include <vte/vte.h>

static void
drain_main_context(void)
{
	int i;

	for (i = 0; i < 150; i++) {
		while (g_main_context_iteration(NULL, FALSE))
			;
		g_usleep(1000);
	}
}

static gboolean
regions_equal(GdkPixbuf *pixbuf, int x, int y1, int y2, int width, int height)
{
	const guchar *pixels = gdk_pixbuf_get_pixels(pixbuf);
	int stride = gdk_pixbuf_get_rowstride(pixbuf);
	int channels = gdk_pixbuf_get_n_channels(pixbuf);
	int row;

	for (row = 0; row < height; row++) {
		const guchar *first = pixels + (y1 + row) * stride + x * channels;
		const guchar *second = pixels + (y2 + row) * stride + x * channels;

		if (memcmp(first, second, width * channels) != 0)
			return FALSE;
	}
	return TRUE;
}

int
main(int argc, char **argv)
{
	GtkWidget *window;
	GtkWidget *widget;
	VteTerminal *terminal;
	GtkBorder *border = NULL;
	GdkPixbuf *pixbuf;
	GdkColor foreground = { 0, 0xffff, 0xffff, 0xffff };
	GdkColor background = { 0, 0, 0, 0 };
	int x, y, width, height;
	gboolean italic_differs, reset_matches;

	if (!gtk_init_check(&argc, &argv)) {
		g_printerr("a running X server is required\n");
		return 77;
	}

	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	widget = vte_terminal_new();
	terminal = VTE_TERMINAL(widget);
	vte_terminal_set_font_from_string(terminal, "DejaVu Sans Mono 20");
	vte_terminal_set_colors(terminal, &foreground, &background, NULL, 0);
	vte_terminal_set_size(terminal, 8, 5);
	gtk_container_add(GTK_CONTAINER(window), widget);
	gtk_widget_show_all(window);

	vte_terminal_feed(terminal,
			  "\033[?25lMMMM\r\n\033[3mMMMM\033[23m\r\nMMMM\r\n",
			  -1);
	drain_main_context();

	gtk_widget_style_get(widget, "inner-border", &border, NULL);
	x = border != NULL ? border->left : 0;
	y = border != NULL ? border->top : 0;
	width = 4 * vte_terminal_get_char_width(terminal);
	height = vte_terminal_get_char_height(terminal);
	pixbuf = gdk_pixbuf_get_from_drawable(NULL,
					      gtk_widget_get_window(widget),
					      NULL, x, y, 0, 0,
					      width, 3 * height);
	if (border != NULL)
		gtk_border_free(border);

	if (pixbuf == NULL) {
		g_printerr("could not capture rendered terminal rows\n");
		gtk_widget_destroy(window);
		return 1;
	}

	italic_differs = !regions_equal(pixbuf, 0, 0, height,
					width, height);
	reset_matches = regions_equal(pixbuf, 0, 0, 2 * height,
				      width, height);
	if (!italic_differs || !reset_matches)
		g_printerr("italic rendering: differs=%d, SGR 23 reset=%d\n",
			   italic_differs, reset_matches);

	g_object_unref(pixbuf);
	gtk_widget_destroy(window);
	drain_main_context();
	return italic_differs && reset_matches ? 0 : 1;
}
