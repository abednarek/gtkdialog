# Notatki techniczne

## Wybór źródła bazowego

Bazą jest oficjalny tarball GNOME `vte-0.28.2.tar.xz`, opublikowany
2011-08-28 w archiwum GNOME:

```text
https://download.gnome.org/sources/vte/0.28/vte-0.28.2.tar.xz
SHA256: 86cf0b81aa023fa93ed415653d51c96767f20b2d7334c893caba71e42654b0ae
```

0.28.2 to ostatnie stabilne wydanie gałęzi 0.28 i ostatnia sensowna baza
łącząca API VTE 0.0 z obsługą GTK2. Nowsze linie rozwoju VTE skupiły się na
GTK3 i zmieniły API/ABI. Użycie oficjalnego tarballa daje audytowalny punkt
startowy oraz komplet wygenerowanych plików autotools, więc zwykły konsument
nie musi uruchamiać `autogen.sh`.

Jako źródła poprawek porównano utrzymywane pakiety Debian/Fedora i historyczny
pakiet Alpine. Nie przyjęto całego patchsetu żadnej dystrybucji: zawiera on
zmiany zachowania terminala, które należy oceniać oddzielnie od przenośności.

Upstreamowa gałąź 0.28 nie jest już rozwijana. Debian nadal publikuje źródło
`vte` 0.28.2 z własnymi poprawkami, Fedora utrzymuje pakiet zgodny z nowym
toolchainem, a Alpine historycznie pakował 0.28.2 i usunął pierwszy blocker
musl. Ten fork przejmuje więc odpowiedzialność za poprawki bezpieczeństwa,
toolchainu i regresji GTK2.

## Licencja

`COPYING` zawiera GNU Library General Public License version 2. Nagłówki
źródłowe pozwalają na wersję 2 lub późniejszą, dlatego identyfikator SPDX dla
pakietu to `LGPL-2.0-or-later`. Import zachowuje informacje copyright i tekst
licencji.

## API i ABI

Wariant GTK2 konfiguruje:

- API VTE `0.0`;
- moduł pkg-config `vte`;
- katalog nagłówków `include/vte-0.0/vte`;
- bibliotekę `libvte.so.9`.

Numery `0.28.2-gtk2.N` identyfikują wydania utrzymywanego forka. Nie są
wpisywane do historycznych makr wersji VTE ani libtoolowego tripletu, ponieważ
mogłoby to zmienić wyniki kontroli wersji w starych konsumentach bez faktycznej
zmiany API. Pakujący może przełożyć ten numer na składnię swojej dystrybucji,
zachowując `0.28.2` jako wersję zgodności biblioteki.

Pierwszy etap nie usuwa publicznych deklaracji ani symboli, także oznaczonych
jako deprecated. Nie zmienia libtoolowego tripletu ani listy eksportów.
Wyłączenie Python 2, introspekcji i helpera PTY w proponowanym profilu pakietu
nie zmienia ABI biblioteki C. Każda przyszła zmiana publicznego nagłówka,
eksportu, sygnału GObject lub semantyki sekwencji terminalowej ma być osobnym
commitem z testem i opisem wpływu.

## Zależności

| Element | Minimum / rola | Wniosek dla pakietu |
| --- | --- | --- |
| GTK+ 2 | 2.20; widget, GDK i backend X11 | wymagane build/runtime |
| GLib/GObject/GIO | 2.26; typy, pętla zdarzeń, procesy i I/O | wymagane build/runtime |
| Pango | 1.22; układ i rysowanie tekstu | wymagane build/runtime |
| Cairo/cairo-xlib | rysowanie; bezpośrednio wymagane dla GDK X11 | wymagane przez profil X11 |
| ATK | implementacja dostępności `VteTerminalAccessible` | wymagane, zwykle przez GTK2 |
| X11 | bezpośrednie użycie przy backendzie GDK X11 | wymagane przez profil X11 |
| ncurses/tinfo/curses/termcap | `tgetent` i nagłówki termcap | jedna działająca implementacja wymagana |
| intltool/gettext | katalogi tłumaczeń | tylko build (libintl zależnie od libc) |
| autotools/libtool/pkg-config | system budowania i wykrywanie bibliotek | tylko build |
| Python 2 + PyGTK 2 | stare opcjonalne bindingi, tylko GTK2 | zachowane w źródle, wyłączone w pakiecie |
| GObject Introspection | opcjonalne metadane GIR | wyłączone w minimalnym profilu |
| gtk-doc | generowanie dokumentacji API i upstreamowego `make dist-xz` | tylko środowisko wydaniowe; wyłączone w zwykłym buildzie |
| libxml2 | brak bezpośrednich odwołań w bibliotece | nie jest zależnością VTE |
| zlib | brak bezpośrednich odwołań w bibliotece | nie jest zależnością VTE |

Dokładne wymagania pkg-config biblioteki to GLib, GObject, GIO, GIO-unix,
Pango i GTK2 oraz — dla GDK/X11 — X11 i cairo-xlib. Zależności końcowego APK
powinny zostać wyznaczone przez `abuild`, a nie wpisane ręcznie bez potrzeby.

## Wyniki analizy przenośności

### musl

Pierwsza kompilacja niezmienionego 0.28.2 na Alpine zatrzymała się w
`src/pty.c`: deklaracja `ptsname_r()` nie była widoczna. Skrypt `configure`
włączał `_GNU_SOURCE` tylko po wykryciu glibc, mimo że musl również osłania tę
deklarację makrem feature-test. `_GNU_SOURCE` jest teraz definiowane lokalnie
przed nagłówkami w `pty.c`. To wąska poprawka kompilacji, zgodna z dawną
poprawką Alpine.

Stare `config.guess`/`config.sub` nie znały współczesnych tripletów musl.
Zostały zastąpione aktualnymi kopiami GNU config zarówno na poziomie głównym,
jak i w `gnome-pty-helper`. Sprawdzono canonicalizację tripletów
`x86_64-alpine-linux-musl` i `aarch64-alpine-linux-musl`.

Po tych zmianach biblioteka i helper PTY kompilują się na Alpine 3.24.1,
musl 1.2.6 i GCC 15.2.0. Testy automatyczne biblioteki oraz dziewięć testów
integracyjnych GTK2 pod Xvfb przechodzą. Nie przeprowadzono uprzywilejowanej
instalacji helpera.

Bufor nazwy strony podrzędnej zwracany przez `_vte_pty_ptsname()` jest
alokowany dynamicznie. Ścieżka Unix98 przechowuje go w prywatnym stanie PTY,
dlatego zwalnia go zarówno przy finalizacji obiektu, jak i przy częściowym
niepowodzeniu konfiguracji. Valgrind potwierdził usunięcie wycieku 1024 bajtów
na każdą utworzoną sesję. Zmiana dotyczy wyłącznie prywatnej własności pamięci;
SONAME, eksportowane symbole, publiczne struktury oraz zachowanie PTY pozostają
bez zmian.

### glibc i nowy toolchain

Nie stwierdzono blokera wynikającego z samej glibc. Niezmienione źródło nie
budowało się jednak współczesnym GCC/GLib z powodu zaostrzonej kontroli typów:

- `src/reaper.c`: wynik `g_object_ref()` wymaga jawnego rzutowania;
- `src/trie.c`: poprawiono const-correctness wskaźnika;
- `src/vteconv.c`: poprawiono typy wskaźników bufora iconv;
- `src/ssfe.c`: zastąpiono nieograniczone `sprintf()` przez `snprintf()` i
  zwiększono bufor sekwencji kursora.

Te same zmiany są potrzebne lub korzystne na musl. Po ich zastosowaniu build
i `make check` przechodzą na Debianie 13, glibc 2.41 i GCC 14.2.0. Zarówno
glibc, jak i musl zgłaszają ostrzeżenia o API przestarzałych od czasu wydania
VTE 0.28; nie należy ich mechanicznie usuwać kosztem starego ABI.

## UTF-8 i kompresja

Wewnętrznym formatem tekstu VTE pozostaje UTF-8. Poprawiono zachowanie na
granicach odczytów z PTY, obsługę buforów z bajtem NUL oraz rozróżnienie
niepełnych i niepoprawnych sekwencji wielobajtowych. Te zmiany nie dodają
nowego kodowania, nie zmieniają publicznego API i są objęte testem `vteconv`
uruchamianym przez `make check`.

XZ jest właściwym formatem dystrybucji archiwum źródłowego; klasyczny cel
autotools `make dist-xz` jest zachowany. Odziedziczone reguły gtk-doc wymagają
narzędzi gtk-doc do utworzenia archiwum nawet wtedy, gdy zwykły build był
skonfigurowany bez dokumentacji. Jest to zależność wyłącznie środowiska
wydaniowego i powinna być spełniana w kontenerze. Nie dodajemy `liblzma` jako
zależności runtime ani kompresji scrollbacku XZ. Taka kompresja utrudniłaby
obsługę interaktywnego, często modyfikowanego bufora i zwiększyłaby zakres
zmian. Jeżeli pomiary wykażą problem z pamięcią scrollbacku, osobno należy
ocenić blokową kompresję z losowym dostępem, bez zmiany API/ABI.

Sprawdzony profil wydaniowy używa `--enable-gtk-doc` i konfiguruje
`gnome-pty-helper`, choć końcowy APK może go nie instalować. `make dist-xz`
utworzył archiwum zawierające dokumentację forka, kontrolę ABI, przykład oraz
szkic pakowania. Czysty build z ponownie rozpakowanego archiwum przechodzi na
musl. Profil `make distcheck` został skorygowany z odziedziczonego GTK3 na
GTK2, z wyłączonymi bindingami Python 2 i introspekcją. Archiwum testowe
pozostało poza repozytorium.

## Polityka changeloga i wydań

`CHANGELOG.md` jest materiałem do publikacji. Zawiera skutki widoczne dla
użytkowników, administratorów i autorów pakietów, a nie pełną listę commitów.
Wpis trafia do `Unreleased` razem ze zmianą kodu; przy wydaniu sekcja otrzyma
numer zachowujący bazę upstreamu, np. `0.28.2-gtk2.1`, oraz datę ISO. Zmiany
bezpieczeństwa, kompatybilności i ewentualne zmiany API/ABI są zawsze nazwane
jawnie. Porządki wewnętrzne i testy są wymieniane tylko wtedy, gdy zmieniają
obsługiwaną macierz lub dają użytkownikowi istotną gwarancję.

## Klasyfikacja zmian

### Przenośność i toolchain — zastosowane

- feature-test `_GNU_SOURCE` dla `ptsname_r()` na musl;
- nowe `config.guess` i `config.sub`;
- poprawki typów wymagane przez współczesne GCC/GLib;
- bezpieczne formatowanie małego bufora w narzędziu testowym `ssfe`.

### Bezpieczeństwo — zastosowane osobno

- ograniczenia rozmiaru tabeli parsera i argumentów sekwencji z
  CVE-2012-2738, przeniesione z patchsetu Debian.
- nasycające przeliczanie parametrów liczbowych w obu historycznych matcherach,
  eliminujące przepełnienie signed integer przed istniejącym limitem 65535;
- limit 4096 znaków parametrów CSI i danych OSC/DCS, zgodny z późniejszą
  polityką parsera VTE; zbyt długa komenda jest ignorowana aż do znaku
  końcowego CSI, BEL lub ST, więc jej ogon nie trafia na ekran jako zwykły
  tekst. Jest to prywatna zmiana zachowania parsera, bez zmiany API, ABI ani
  formatu poprawnych sekwencji.

Testy graniczne parsera przechodzą na glibc i musl. Dodatkowy, czysty build
Alpine/musl z `-fsanitize=address,undefined` oraz `make check` również
przeszedł; wykrywanie wycieków było wyłączone, ponieważ ten etap sprawdzał
błędy dostępu do pamięci i niezdefiniowane zachowanie w reproduktorach.

### Funkcjonalne — oceniane osobno

Baza 0.28.2 już zawiera bracketed paste, więc nie wymaga ono portu. Z nowszego
VTE przeniesiono natomiast natychmiastowe odrysowanie po OSC 4, semantykę
bold/dim/standout dla jawnych indeksów palety 256 kolorów oraz raportowanie
myszy xterm SGR 1006. Są to osobne, przetestowane zmiany zachowania. Tryb 1006
jest stanem prywatnym, zachowuje stare kodowanie jako fallback i nie dodaje
symbolu publicznego.

Zmiany Alt/Meta, Home/End, modyfikatorów klawiatury i raportowania fokusu
zostały już przeniesione jako małe, rozdzielone poprawki z reproduktorami.
Nie importujemy zbiorczo kolejnych zmian ani optymalizacji przewijania. Źródłem
wiedzy może być VTE3, ale implementacja nie może kopiować jego modelu GTK3 ani
wymuszać nowego API.

Obsługa xterm `CSI 3 J` zachowuje semantykę późniejszego upstreamowego VTE
(commit `3111d449`): odrzuca historię normalnego ekranu przed jego bieżącym
`insert_delta`, zachowuje widoczne wiersze i aktualizuje zakres przewijania.
Normalny ekran jest jedynym buforem, któremu stare API przydziela scrollback,
dlatego sekwencja wysłana na ekranie alternatywnym również czyści historię
normalnego ekranu. Implementacja dodaje wyłącznie funkcje prywatne i nie
eksportuje nowego symbolu ani nie zmienia układu struktur publicznych.

Poprawka szerokości ramek CJK pochodzi z upstreamowego commita `f201235`
z 2012 roku i mieści się w tej samej licencji pliku. Obejmuje zakres
U+2500..U+259F, aby neutralne znaki ramek oraz bloków nie rozjeżdżały się
z sąsiednimi znakami ambiguous. Działa wyłącznie przy istniejącym ustawieniu
`VTE_CJK_WIDTH=wide`; szerokość domyślna, API i ABI pozostają bez zmian.

Upstreamowy commit `9240ed8` zachowuje całe oczekujące wejście przy każdym
resecie. W tym forku port jest węższy: RIS i DECSTR zachowują dalsze bajty tego
samego strumienia, ale publiczne `vte_terminal_reset()` nadal odrzuca
nieprzetworzone wejście zgodnie ze swoją historyczną dokumentacją. Prywatna
ścieżka resetu nie dodaje symbolu eksportowanego. Przykład
`vte-reset-stream-test` sprawdza oba zachowania pod X11.

Reset czyszczący historię dodatkowo wymusza kolejkę aktualizacji adjustmentu
zgodnie z upstreamowym commitem `8fbb9722`. Bez wymuszenia optymalizacja
pomijała rzadki przypadek, w którym liczbowa wartość wyglądała na niezmienioną
mimo przebudowy ringów, pozostawiając nieaktualny scrollbar lub obraz. Zmiana
dotyczy wyłącznie prywatnej synchronizacji GTK2; publiczny obiekt
`GtkAdjustment` i jego API pozostają te same. Test resetu sprawdza powrót
wartości adjustmentu do początku po usunięciu scrollbacku.

Zmiany limitu scrollbacku aktualizują teraz oba ringi niezależnie od tego,
który ekran jest widoczny, zgodnie z upstreamowym commitem `645c499d`.
Programowe `vte_terminal_set_size()` natychmiast dopasowuje oba ringi i
ogranicza oba kursory zamiast czekać na późniejszy sygnał
`GtkWidget::size-allocate`; jest to wąski port idei z commita `4425ee07`, bez
przenoszenia późniejszego mechanizmu rewrap. Publiczna semantyka metody i
oddzielne treści ekranów pozostają bez zmian. Test resetu przełącza ekran
alternatywny, zmienia rozmiar i limit historii, po czym sprawdza rozmiar oraz
izolację obu buforów.

Obsługa fragmentów TAB/CJK została przeniesiona z upstreamowych commitów
`4d6edfb`, `b9dad4a`, `1052bc6` i `67e9cf6` z 2014 roku. Sam ruch kursora nie niszczy już zwartej
reprezentacji tabulatora. Dopiero operacja modyfikująca wiersz zamienia lewą
część przeciętego TAB na spacje, zachowuje jego prawą część jako krótszy TAB
i zastępuje osieroconą połowę znaku dwukolumnowego spacją. Naprawa obejmuje
nadpisywanie, insert/delete/erase oraz wypchnięcie poza prawą krawędź. Dodane
funkcje są prywatne. Kursor nad wewnętrzną częścią zwartego TAB ma szerokość
jednej komórki. Układ publicznych struktur, lista eksportów i semantyka API
VTE 0.0 pozostają niezmienione. Test `vte-cell-fragment-test` sprawdza wynik
przez publiczne API ekstrakcji tekstu pod X11.

Audyt pozostałych sekwencji erase/insert nie wskazał kolejnego prostego portu.
Baza obsługuje już ICH, IL, DCH, DL i ECH. Selective erase (`CSI ? Ps J/K`)
wymaga najpierw zaprojektowania i przetestowania atrybutu ochrony komórki,
zwłaszcza jego zachowania przy kopiowaniu, przewijaniu i zmianie rozmiaru.
REP (`CSI Ps b`) pozostaje niezaimplementowane także w sprawdzonej wersji
upstream VTE 0.38.4; poprawna obsługa musi powtarzać poprzedni znak wraz ze
znakami łączącymi. Obu funkcji nie włączamy przez samo podpięcie istniejących
nazw parsera, ponieważ dawałoby to pozorną, niepełną zgodność.

Niskiego ryzyka poprawki pozycji kursora pochodzą z późniejszego upstreamu:
IL/DL wracają do pierwszej kolumny (`83d03666`), tryb origin poprawnie ustawia
home i ogranicza CUP/VPA do marginesów (`a2a49dfd`, `71aadaf2`), `ESC E`
przewija na dolnym marginesie (`b04ccce0`), a operacje ruchu, edycji,
czyszczenia, LF/RI, odtworzenia kursora i raportowania pozycji rozpoczynają się
od widocznej ostatniej kolumny przy oczekującym autowrapie (`817b6834`).
Wyjątki scroll-up/down zachowują semantykę xterm. Wszystkie zmiany dotyczą
prywatnej emulacji, nie dodają symboli
i są objęte `vte-sequence-test`. DECCOLM (`CSI ? 3 h/l`) pozostaje wyłączone:
baza celowo nie pozwala strumieniowi terminala zmieniać rozmiaru widgetu
ustalanego przez aplikację GTK2.

Standardowy DSR (`CSI 6 n`) i wariant DEC (`CSI ? 6 n`) raportują teraz wiersz
względem początku regionu przewijania, gdy działa origin mode, tak jak późniejszy
upstream w tej samej serii poprawek. Kolumna jest nadal jednoindeksowana, a
wartości są ograniczone do widocznego obszaru. Test PTY przełącza origin mode,
ustawia marginesy i porównuje dokładne odpowiedzi `CSI 2;4 R` oraz
`CSI ? 2;4 R` od strony procesu potomnego.

Przed użyciem kodu z późniejszego VTE trzeba sprawdzić licencję konkretnego
commita i plików. Gdy ich warunki są węższe niż `LGPL-2.0-or-later` tej bazy,
korzystamy ze specyfikacji protokołu i piszemy własną małą implementację albo
rezygnujemy z portu; nie kopiujemy kodu kosztem niejawnej zmiany licencji
całego forka.

Granice pustego obszaru cache dopasowań GRegex skorygowano zgodnie z
upstreamowym commitem `d3368a3f`. Koniec dopasowania GLib jest ekskluzywny,
natomiast współrzędne komórek VTE są inkluzywne; wcześniejsze pomieszanie tych
konwencji mogło ukrywać link lub inny match sąsiadujący ze znakiem bez
dopasowania. `vte-match-test` odtwarza oba kierunki błędu przez publiczne API.

## Plan poprawy użyteczności bez zmiany API/ABI

Kolejność jest celowa: najpierw poprawność i protokoły możliwe do objęcia
testami bez GUI, następnie rendering i integracja wymagające X11.

1. **Bezpieczeństwo i parser.** Pierwszy przegląd CVE, limity CSI/OSC/DCS,
   testy graniczne oraz przebieg ASan/UBSan są wykonane. Oba historyczne
   matchery wykonują w `make check` deterministyczny korpus 40 tys. wejść z
   sekwencjami sterującymi, NUL i Unicode. Zewnętrzny fuzzing sterowany
   pokryciem oraz sanitizer powinny pozostać okresowym zadaniem kontenerowym,
   a nie zależnością zwykłego builda. Nie zmieniać akceptowanego API C.
2. **Wejście klawiatury.** Alt/Meta, Home/End, klawiatura aplikacyjna i
   modyfikatory zostały porównane z xterm oraz poprawione bez nowej
   właściwości publicznej. Następne różnice wymagają jednoznacznego testu.
3. **Protokoły terminalowe niskiego ryzyka.** Raportowanie fokusu DECSET 1004,
   kształt kursora DECSCUSR, czyszczenie historii przez `CSI 3 J` oraz
   poprawki IL/DL, origin/HPA/VPA, NEL i prawego marginesu są wykonane. Dalej
   ocenić pozostałe warianty erase/insert. Funkcje mają być
   aktywowane wyłącznie sekwencją programu terminalowego.
4. **Unicode.** Publiczny test obejmuje UTF-8 rozdzielone między porcjami,
   znaki łączące, CJK, mapowanie bajtów na kolumny i kopiowanie przez schowek.
   Zgodność ramek U+2500..U+259F z istniejącym trybem `VTE_CJK_WIDTH=wide`
   jest poprawiona i testowana. Dalej audytowalnie aktualizować tablice
   szerokości znaków. Emoji, grapheme
   clusters i zmianę domyślnej polityki ambiguous-width traktować jako osobny
   projekt, bo stary model komórki VTE może wymagać głębszej przebudowy mimo
   niezmienionego ABI zewnętrznego.
5. **Kolory.** Publiczny test sprawdza indeksy palety 256 przy bold/dim,
   tło oraz zmianę już użytego koloru przez OSC 4. Truecolor `38;2`/`48;2`
   jest dostępny przez `--enable-truecolor`; zachowuje dokładne RGB zamiast
   mapować je po cichu do palety 256.
6. **Schowek i selekcja.** Bracketed paste, stan osobny dla ekranu normalnego
   i alternatywnego, wielobajtowy tekst, konwersja LF oraz wklejenie 64 KiB są
   objęte testem z rzeczywistym schowkiem X11 i PTY. Syntetyczny Ctrl-drag
   sprawdza zawartość prostokątnego zaznaczenia przez PRIMARY, również gdy
   przecina znak CJK. Z commitów `b446923` i `9ef0dcf` przeniesiono prywatne
   poszerzenie unieważnianego obszaru o maksymalną szerokość TAB, co usuwa
   pozostające fragmenty podświetlenia. Nie zmienia to treści zaznaczenia ani
   API/ABI. Poprawki `73745f9f` i `49cacf86` centralizują początkowe
   wyznaczenie obszaru zaznaczenia i zawsze kończą lokalne zaznaczenie przy
   puszczeniu przycisku, także gdy Shift puszczono wcześniej w trybie
   raportowania myszy. Test syntetyczny obejmuje ten przypadek. Dalej
   sprawdzić kopiowanie końców linii w większym korpusie.
7. **Rendering i przewijanie.** Poprawność fragmentów TAB/CJK przy ruchu,
   nadpisywaniu, erase/delete i prawej krawędzi jest wykonana. Dalej profilować
   uszkodzone regiony, scrollback i cache fontów na GTK2/X11. Portować
   optymalizacje VTE3 tylko tam, gdzie nie zależą od Cairo/GTK3 w sposób
   zmieniający stary renderer.
8. **PTY i cykl życia procesu.** Test publicznego API obejmuje rozmiar PTY,
   szybkie zakończenie z kodem wyjścia, pojedynczy sygnał `child-exited`,
   sprzątanie dziecka po zniszczeniu widgetu i reset odziedziczonego SIGQUIT.
   Brakujący reset SIGQUIT przeniesiono z upstreamowego commita `a6b92987`;
   jest to poprawka prywatnej ścieżki przed `exec()`, bez wpływu na ABI/API.
   Helper pozostaje opcjonalny i wymaga oddzielnego audytu uprawnień, jeżeli
   przyszły integrator zechce go instalować.
9. **Macierz jakości.** Utrzymywać `make check` i straż 134 eksportów na musl
   i glibc. Testy GTK2 pod Xvfb dla x86_64 są wykonane na obu libc. Dodać
   natywny lub emulowany runner aarch64 oraz mały zestaw realnych aplikacji
   (shell, ncurses, edytor z myszą i bracketed paste).
10. **Wydanie i APK.** Dopiero po powyższych bramkach utworzyć oznaczony
    tarball XZ, zbudować APK pod `/opt/gtk2` w osobnym repo aports i sprawdzić
    brak kolizji `vte.pc`, nagłówków oraz `libvte.so.9` z `/usr`.

Poza zakresem tej linii pozostają port renderera GTK3, usuwanie historycznych
symboli, dodawanie publicznych klas z VTE3 oraz kompresja scrollbacku przez XZ.
Te zmiany nie są potrzebne do poprawy zgodności aplikacji korzystających ze
starego VTE 0.0 i niosłyby nieproporcjonalne ryzyko.

Dwie małe poprawki starego renderera pozostają niezależne od GTK3: usunięcie
timera migania przywraca i unieważnia widoczny kursor (`39941021`), a obszar
preedit IM jest przesuwany w lewo zamiast wychodzić poza prawy margines
(`8676cb76`). Nie zmieniają publicznych ustawień kursora ani integracji IM,
jedynie naprawiają ich istniejące zachowanie. Są objęte kompilacją i zestawem
GUI; dokładne pozycjonowanie preedit należy nadal sprawdzać ręcznie z wybranym
modułem wejściowym używanym na Desk.

Italic jest przeniesiony z upstreamowego commita `ad68297c`. Prywatny atrybut
komórki wykorzystuje jeden z dwóch wolnych bitów istniejącego 32-bitowego
`VteCellAttr`, więc `VteCell` nadal ma 8 bajtów, a format zamrożonych wierszy
ringu zachowuje ten sam rozmiar rekordu. Renderer utrzymuje cztery prywatne
warianty fontu Pango i rozdziela serie rysowania także po atrybucie italic.
SGR 3 włącza styl, SGR 23 go wyłącza, a SGR 0 używa istniejącego resetu
atrybutów. Nie dodano pola do publicznego `VteCharAttributes`, właściwości ani
symbolu. `vte-style-test` porównuje piksele identycznego tekstu regularnego,
italic i tekstu po SGR 23 pod Xvfb na obu libc.

Truecolor opiera się na projekcie upstreamowego commita `c5a32b49`, ale jest
warunkowany przy konfiguracji. Bez flagi prywatny `VteCell` pozostaje
8-bajtowy. Z `--enable-truecolor` pola kolorów mają po 25 bitów, a spakowana
komórka 12 bajtów; zapisuje ona znacznik i pełne RGB. Dwa dodatkowe prywatne
sloty renderera służą jedynie do przekazania bieżących kolorów staremu
backendowi paletowemu. Nie są widoczne jako indeksy palety. Publiczne
`VteCharAttributes` zwraca dokładny kolor, a wklejane atrybuty Pango zachowują
RGB. Oba warianty eksportują te same 134 symbole i `libvte.so.9`; żaden
publiczny typ nie zmienił rozmiaru. Build, `make check`, test RGB pod Xvfb i
straż ABI przeszły na glibc oraz musl x86_64.

Ring zachowuje teraz co najmniej cały widoczny ekran w części zapisywalnej w
pamięci, zgodnie z ideą upstreamowego commita `5ad51c95`. Wysokość jest
prywatną wskazówką ustawianą równolegle dla ekranu normalnego i alternatywnego;
nie zmienia limitu scrollbacku ani semantyki publicznego API. Tablica ringu
rośnie, zanim zamrożenie wiersza mogłoby objąć nadal widoczną treść. Test
resetu obejmuje terminal o 80 wierszach, czyli większy od historycznej
32-wierszowej części zapisywalnej, i sprawdza zachowanie pierwszego oraz
ostatniego widocznego wiersza.

Plikowy backend scrollbacku przechowuje prywatnie długości obu stron strumienia
i aktualizuje je przy append, truncate, reset i zamianie stron. Dzięki temu
odczyt głowy i obrót strony nie wykonują dodatkowego `lseek(..., SEEK_END)`;
pozycjonowanie wymagane po wcześniejszym odczycie pozostaje w append. Bufory
serializacji wiersza są zerowane przez `g_string_truncate()`, co jawnie
zachowuje przydzieloną pamięć. Zmiany nie dotykają formatu zamrożonego wiersza,
publicznych struktur, eksportów ani SONAME.

## Macierz sprawdzeń pierwszego etapu

| Środowisko | Profil | Wynik |
| --- | --- | --- |
| Debian 13, glibc 2.41, GCC 14.2 | GTK2, bez Python/GIR/gtk-doc/helpera | build, `make check` i dziewięć testów Xvfb: OK |
| Alpine 3.24.1, musl 1.2.6, GCC 15.2 | GTK2, bez Python/GIR/gtk-doc/helpera | build, `make check` i dziewięć testów Xvfb: OK |
| Debian 13 / Alpine 3.24.1 | jak wyżej, helper włączony | build: OK; test setuid/utmp odłożony |

W obu podstawowych przebiegach pięć testów kończy się sukcesem, w tym test
konwersji UTF-8 `vteconv` i test klasyfikacji szerokości `iso2022`. Kontrola
składni dokumentacji na Alpine informuje o braku GNU grep, ale nie jest testem
kodu ani porażką zestawu. Skrypt `abi/check-abi.sh` potwierdza SONAME
`libvte.so.9` i niezmienny zestaw 134 symboli w obu środowiskach.
Dziewięć testów publicznego API przechodzi na obu libc pod Xvfb; wymagają
dostępnego pliku termcap pasującego do testowanej biblioteki. Test resetu
SIGQUIT uruchamia bezpośrednio własny program potomny. Nie używa powłoki,
ponieważ nieinteraktywny BusyBox `ash` sam ignoruje ten sygnał i fałszowałby
wynik niezależnie od zachowania VTE.

## Plan przed pierwszym APK

1. Utworzyć podpisany, niezmienny tarball z konkretnego commita i wpisać jego
   sumę SHA512 do APKBUILD w osobnym repo aports.
2. Budować w czystym środowisku `abuild` dla co najmniej x86_64 i aarch64.
3. Zainstalować pod `/opt/gtk2`; nie publikować drugiego `vte.pc` ani
   `libvte.so.9` w `/usr`.
4. Sprawdzić ładowanie biblioteki bez stałego RPATH. Politykę ścieżki loadera
   powinien zapewnić wspólny runtime `/opt/gtk2` lub kontrolowany launcher.
5. Uruchomić `make check`, przykład GUI i rzeczywistą aplikację GTK2 używającą
   starego API VTE.
6. Zdecydować, czy wymagane są rejestry logowania. Jeżeli tak, wykonać audyt
   helpera i przygotować osobny subpakiet zamiast instalować setuid domyślnie.
7. Porównać eksportowane symbole z oczekiwaniami konsumentów i zamrozić plik
   symboli dla kolejnych wydań.
