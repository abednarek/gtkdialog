# Szkic pakietu Alpine dla `/opt/gtk2`

Ten katalog opisuje docelowe pakowanie, ale właściwy APKBUILD powinien żyć w
osobnym, prywatnym repozytorium aports. `APKBUILD.example` nie jest gotowy do
publikacji: wymaga stabilnego URL tarballa, wersji forka i prawdziwej sumy
SHA512.

Założenia pierwszego pakietu:

- nazwa `vte-gtk2`, żeby nie kolidować z innymi liniami VTE;
- cały payload pod `/opt/gtk2`;
- C API/ABI upstreamu: `vte.pc`, `libvte.so.9`, nagłówki `vte-0.0`;
- Python 2, GIR, gtk-doc i `gnome-pty-helper` wyłączone;
- standardowy podział `-dev` i `-lang` przez funkcje `abuild`;
- brak wbudowanego RPATH do prywatnego drzewa.

Przed użyciem szkicu:

1. Opublikuj tarball wygenerowany z konkretnego taga/commita `gtk2-apps` w
   miejscu dostępnym dla buildera bez interaktywnego logowania. Nie używaj
   ruchomej gałęzi jako źródła wydania.
2. Zastąp `REPLACE_WITH_*` w `APKBUILD.example` i wygeneruj `sha512sums` przez
   `abuild checksum`. Nie zatwierdzaj `SKIP` dla wydania.
3. Zweryfikuj listę `makedepends` na aktualnej gałęzi Alpine i pozwól `abuild`
   wyliczyć zależności runtime z ELF.
4. Uzgodnij jedną politykę uruchomieniową dla całego stosu `/opt/gtk2`: plik
   konfiguracyjny loadera lub launcher ustawiający ścieżki. Nie kopiuj symlinków
   biblioteki ani pliku pkg-config do `/usr`.
5. Zbuduj w czystym kontenerze/chroot `abuild`, uruchom `check()` i sprawdź
   pakiet przez `apk add --root ...` przed instalacją na hoście.

`gnome-pty-helper` powinien dostać osobny subpakiet dopiero po audycie. Wymaga
to jawnych owner/mode, przeglądu zapisu utmp/wtmp/lastlog na musl oraz testu
modelu uprawnień na docelowym systemie.
