#!/bin/sh

set -eu

if test "$#" -ne 1; then
	echo "usage: $0 /path/to/libvte.so.9" >&2
	exit 2
fi

library=$1
if ! test -f "$library"; then
	echo "ABI check: library not found: $library" >&2
	exit 2
fi

script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
expected_symbols=$script_dir/libvte.so.9.symbols
actual_symbols=$(mktemp "${TMPDIR:-/tmp}/vte-gtk2-symbols.XXXXXX")
trap 'rm -f "$actual_symbols"' EXIT HUP INT TERM

soname=$(readelf -d "$library" |
	awk '/\(SONAME\)/ { value=$NF; gsub(/^\[|\]$/, "", value); print value }')

if test "$soname" != libvte.so.9; then
	echo "ABI check: expected SONAME libvte.so.9, found ${soname:-none}" >&2
	exit 1
fi

LC_ALL=C nm -D --defined-only "$library" |
	awk 'NF >= 3 { symbol=$NF; sub(/@.*/, "", symbol); print symbol }' |
	sort -u > "$actual_symbols"

if ! diff -u "$expected_symbols" "$actual_symbols"; then
	echo "ABI check: exported symbol set changed" >&2
	exit 1
fi

echo "ABI check: libvte.so.9 and exported symbols are unchanged"
