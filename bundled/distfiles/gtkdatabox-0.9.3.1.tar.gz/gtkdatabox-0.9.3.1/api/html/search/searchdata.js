var indexSectionsWithContent =
{
  0: "_abcdefghilmoprstuvwxyz",
  1: "_g",
  2: "g",
  3: "g",
  4: "abcdeghilmoprstuvwxyz",
  5: "g",
  6: "g",
  7: "abeglprsz",
  8: "_fglr"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros"
};

