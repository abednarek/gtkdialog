var searchData=
[
  ['zoom_5flimit',['zoom_limit',['../struct__GtkDataboxPrivate.html#a86f5149c082d91fa506a04372a2fd85d',1,'_GtkDataboxPrivate']]],
  ['zoomed',['zoomed',['../struct__GtkDataboxClass.html#a28319cba4476b3daa40ef229fa7a0da7',1,'_GtkDataboxClass']]]
];
