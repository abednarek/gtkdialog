var searchData=
[
  ['calculate_5fextrema',['calculate_extrema',['../struct__GtkDataboxGraphClass.html#aa07652e7b03d8de0b91acd0aec9a0afc',1,'_GtkDataboxGraphClass']]],
  ['color',['color',['../struct__GtkDataboxGraphPrivate.html#abde185e4bd246ac3fd9a63681f258be9',1,'_GtkDataboxGraphPrivate']]],
  ['create_5fgc',['create_gc',['../struct__GtkDataboxGraphClass.html#a4b6db09e659d397d4887899bb5167652',1,'_GtkDataboxGraphClass']]]
];
